# Pruebas funcionales de 06.01. R base; NO validan las estimaciones reales ENE.
# Rscript --vanilla work/verificacion/verificar_06_01.R /ruta/absoluta/proyecto
# Todos los datos y productos sinteticos se crean bajo tempdir() y se eliminan.
# En outputs/ solo se guardan estados de pruebas y este alcance documentado.
local({
  args <- commandArgs(trailingOnly = TRUE)
  if (length(args) != 1L || !dir.exists(args[1L]))
    stop("Indique la ruta absoluta existente del proyecto como unico argumento.")
  raiz <- normalizePath(args[1L], winslash = "/", mustWork = TRUE)
  script <- file.path(raiz, "outputs", "06_01_preparar_base_laboral_AMJ.R")
  originales <- c("01_inventario_ene.R", "02_diagnostico_y_union_ene.R",
    "03_indicadores_laborales_nacionales.R", "04_indicadores_laborales_sexo_edad.R",
    "05_empleo_sectores_productivos.R")
  stopifnot(file.exists(script), all(file.exists(file.path(raiz, "outputs", originales))))
  rscript <- file.path(R.home("bin"), if (.Platform$OS.type == "windows") "Rscript.exe" else "Rscript")
  stopifnot(file.exists(rscript))
  destino <- file.path(raiz, "outputs", "resultados_06_contexto_macroeconomico", "00_revision_insumos")
  dir.create(destino, recursive = TRUE, showWarnings = FALSE)
  pruebas_raiz <- tempfile("pruebas_06_01_SOLO_SINTETICAS_", tmpdir = tempdir())
  dir.create(pruebas_raiz)
  on.exit(unlink(pruebas_raiz, recursive = TRUE), add = TRUE)
  # Evitar que una configuracion personal seleccione una entrada real.
  vars <- c("ENE_PROYECTO", "ENE_CSV_PASO03")
  prev <- Sys.getenv(vars, unset = NA_character_)
  Sys.unsetenv(vars)
  on.exit({
    for (i in seq_along(vars)) {
      if (is.na(prev[i])) Sys.unsetenv(vars[i]) else do.call(Sys.setenv, setNames(list(prev[i]), vars[i]))
    }
  }, add = TRUE)
  escribir <- function(x, ruta) write.csv(x, ruta, row.names = FALSE, na = "", fileEncoding = "UTF-8")
  literal <- function(x) paste(deparse(x), collapse = "")
  tasas <- c("tasa_participacion", "tasa_ocupacion", "tasa_desocupacion")
  problemas <- c("n_edad_faltante", "n_edad_invalida_no_faltante", "n_pet_activ_faltante",
    "n_pet_activ_invalida", "n_pet_peso_faltante", "n_pet_peso_invalido", "n_pet_cae_invalido",
    "n_pet_discrepancia_activ_cae", "n_pet_no_utilizables")
  base_sintetica <- function() {
    k <- seq_along(2010:2025)
    x <- data.frame(anio = 2010:2025, trimestre = "AMJ", n_muestra_pet = 1000L + 10L * k,
      n_muestra_ocupados = 600L + 4L * k, n_muestra_desocupados = 100L,
      n_muestra_fuera_ft = 300L + 6L * k)
    x$pet_personas <- 100 * x$n_muestra_pet
    x$ocupados_personas <- 100 * x$n_muestra_ocupados
    x$desocupados_personas <- 100 * x$n_muestra_desocupados
    x$fuera_ft_personas <- 100 * x$n_muestra_fuera_ft
    x$fuerza_trabajo_personas <- x$ocupados_personas + x$desocupados_personas
    x$tasa_participacion <- 100 * x$fuerza_trabajo_personas / x$pet_personas
    x$tasa_ocupacion <- 100 * x$ocupados_personas / x$pet_personas
    x$tasa_desocupacion <- 100 * x$desocupados_personas / x$fuerza_trabajo_personas
    x
  }
  controles_sinteticos <- function(x) {
    z <- data.frame(anio = x$anio, n_total = x$n_muestra_pet + 300L,
      n_pet = x$n_muestra_pet, n_menores_15 = 300L)
    for (p in problemas) z[[p]] <- 0L
    z
  }
  metadatos_sinteticos <- function() {
    z <- expand.grid(anio = 2010:2025, variable = c("edad", "activ", "cae_especifico", "fact_cal"),
      stringsAsFactors = FALSE)
    z$etiqueta_variable <- ifelse(z$variable == "fact_cal",
      "Factor de prueba 2017, SOLO SINTETICO", paste("Etiqueta SOLO SINTETICA", z$variable))
    z$etiquetas_valores <- "Metadatos ficticios para probar estructura; no INE"
    z
  }
  contraste_sintetico <- function(x) {
    z <- expand.grid(anio = c(2020L, 2025L), indicador = tasas, stringsAsFactors = FALSE)
    z$tasa_calculada <- mapply(function(y, v) x[x$anio == y, v], z$anio, z$indicador)
    z$tasa_publicada <- round(z$tasa_calculada, 1L)
    z$compatible_redondeo <- TRUE
    z
  }
  resultado <- list()
  caso <- function(nombre, transformar = identity, auxiliar = "ninguno", modificar_aux = NULL,
                   exito = TRUE, fallo = "", modo = "source", varias = FALSE,
                   explicito = FALSE, entrada = TRUE, png_falla = FALSE) {
    carpeta <- file.path(pruebas_raiz, nombre)
    dir.create(file.path(carpeta, "outputs"), recursive = TRUE)
    stopifnot(all(file.copy(file.path(raiz, "outputs", originales), file.path(carpeta, "outputs"))))
    stopifnot(file.copy(script, file.path(carpeta, "outputs", basename(script))))
    insumos <- file.path(carpeta, "work", "insumos", "paso_03")
    dir.create(insumos, recursive = TRUE)
    ruta_csv <- file.path(insumos, "indicadores_nacionales_AMJ_2010_2025.csv")
    base <- transformar(base_sintetica())
    if (entrada) escribir(base, ruta_csv)
    if (auxiliar != "ninguno") {
      aux <- list(controles = controles_sinteticos(base), meta = metadatos_sinteticos(),
        contraste = contraste_sintetico(base))
      if (!is.null(modificar_aux)) aux <- modificar_aux(aux)
      escribir(aux$controles, file.path(insumos, "controles_por_anio.csv"))
      escribir(aux$meta, file.path(insumos, "metadatos_utilizados.csv"))
      escribir(aux$contraste, file.path(insumos, "contraste_INE_2020_2025.csv"))
    }
    if (varias) {
      otro <- file.path(carpeta, "outputs", "resultados_indicadores_nacionales", "otra_version")
      dir.create(otro, recursive = TRUE)
      stopifnot(file.copy(ruta_csv, file.path(otro, basename(ruta_csv))))
    }
    entrada_files <- list.files(carpeta, recursive = TRUE, full.names = TRUE)
    hashes_antes <- tools::md5sum(entrada_files)
    otra_carpeta <- file.path(pruebas_raiz, paste0("cwd_ajeno_", nombre))
    dir.create(otra_carpeta)
    lanzador <- file.path(pruebas_raiz, paste0(nombre, "_lanzador.R"))
    lineas <- c("# Ejecutor de prueba; solo entradas sinteticas bajo tempdir().",
      "Sys.unsetenv(c('ENE_PROYECTO', 'ENE_CSV_PASO03'))",
      paste0("setwd(", literal(otra_carpeta), ")"),
      "stopifnot(!exists('ene', envir = .GlobalEnv, inherits = FALSE))")
    if (explicito) lineas <- c(lineas, paste0("Sys.setenv(ENE_CSV_PASO03 = ", literal(ruta_csv), ")"))
    if (png_falla) lineas <- c(lineas,
      "png <- function(...) stop('Fallo PNG inyectado exclusivamente para prueba')")
    lineas <- c(lineas, paste0("source(", literal(file.path(carpeta, "outputs", basename(script))),
      ", chdir = FALSE, encoding = 'UTF-8')"),
      "stopifnot(!exists('ene', envir = .GlobalEnv, inherits = FALSE))")
    writeLines(lineas, lanzador, useBytes = TRUE)
    log <- file.path(pruebas_raiz, paste0(nombre, ".log"))
    cwd_anterior <- getwd()
    if (modo == "cli") setwd(otra_carpeta)
    estado <- tryCatch(suppressWarnings(system2(rscript,
      c("--vanilla", shQuote(if (modo == "cli") file.path(carpeta, "outputs", basename(script)) else lanzador)),
      stdout = log, stderr = log)), finally = setwd(cwd_anterior))
    verificar <- function() {
      stopifnot((estado == 0L) == exito)
      log_lineas <- readLines(log, warn = FALSE)
      if (!exito && nzchar(fallo)) stopifnot(any(grepl(fallo, log_lineas, fixed = TRUE)))
      corridas <- list.dirs(file.path(carpeta, "outputs", "resultados_06_contexto_macroeconomico", "ejecuciones"),
        full.names = TRUE, recursive = FALSE)
      stopifnot(length(corridas) == 1L)
      corrida <- corridas[1L]
      validaciones <- read.csv(file.path(corrida, "controles", "validaciones_06_01.csv"), stringsAsFactors = FALSE)
      leeme <- readLines(file.path(corrida, "documentacion", "LEEME_06_01.md"), warn = FALSE, encoding = "UTF-8")
      stopifnot(file.exists(file.path(corrida, "documentacion", "sesion_R_06_01.txt")))
      stopifnot(identical(unname(tools::md5sum(entrada_files)), unname(hashes_antes)))
      if (exito) {
        csv <- read.csv(file.path(corrida, "tablas", "base_laboral_AMJ_2010_2025.csv"))
        rds <- readRDS(file.path(corrida, "tablas", "base_laboral_AMJ_2010_2025.rds"))
        stopifnot(nrow(csv) == 16L, identical(csv$anio, 2010:2025), all(csv$trimestre == "AMJ"),
          all(csv$trimestre_calendario == "T2"), all(csv$fecha_inicio_AMJ == sprintf("%d-04-01", csv$anio)),
          all(csv$fecha_fin_AMJ == sprintf("%d-06-30", csv$anio)),
          isTRUE(all.equal(csv, rds, check.attributes = FALSE, tolerance = 1e-12)))
        cambios <- read.csv(file.path(corrida, "tablas", "cambios_laborales_interanuales_pp.csv"))
        for (v in tasas) stopifnot(isTRUE(all.equal(cambios[[paste0(v, "_cambio_pp")]],
          c(NA_real_, diff(csv[[v]])), tolerance = 1e-12)))
        stopifnot(file.info(file.path(corrida, "graficos", "01_referencia_laboral_AMJ.png"))$size > 0,
          !any(validaciones$estado %in% c("FALLA", "DETENIDA")))
        if (auxiliar == "ninguno") stopifnot(sum(validaciones$estado == "PENDIENTE") == 3L) else
          stopifnot(!any(validaciones$estado == "PENDIENTE"))
      } else {
        stopifnot(!length(list.files(file.path(corrida, "tablas"))),
          !length(list.files(file.path(corrida, "graficos"))),
          any(validaciones$estado == "DETENIDA"),
          any(grepl("DETENIDO_SIN_BASE_ANALITICA", leeme, fixed = TRUE)),
          !any(grepl("Los tres archivos auxiliares se revisaron", leeme, fixed = TRUE)))
      }
      TRUE
    }
    hallazgo <- tryCatch({ verificar(); "" }, error = function(e) conditionMessage(e))
    # No se vuelcan logs ni datos sinteticos al informe del proyecto.
    resultado[[length(resultado) + 1L]] <<- data.frame(prueba = nombre,
      resultado_esperado = if (exito) "EXPORTA_Y_CONSERVA_ENTRADAS" else "RECHAZA_SIN_PRODUCTOS_ANALITICOS",
      resultado = if (nzchar(hallazgo)) "FALLA" else "PASA", tipo_datos = "SINTETICOS_SOLO_EN_TEMPORAL",
      detalle = if (nzchar(hallazgo)) hallazgo else "Comportamiento esperado; entradas intactas; sin validar datos ENE reales.",
      stringsAsFactors = FALSE)
    message(nombre, ": ", if (nzchar(hallazgo)) paste("FALLA", hallazgo) else "PASA")
    if (nzchar(hallazgo)) message(paste(readLines(log, warn = FALSE), collapse = "\n"))
  }
  caso("source_sesion_nueva_cwd_ajeno_sin_auxiliares", transformar = function(x) x[rev(seq_len(nrow(x))), ])
  caso("source_con_auxiliares_completos", auxiliar = "todos")
  caso("cli_sesion_nueva_cwd_ajeno", modo = "cli")
  caso("falta_csv", entrada = FALSE, exito = FALSE, fallo = "Falta indicadores_nacionales_AMJ_2010_2025.csv")
  caso("varias_versiones", varias = TRUE, exito = FALSE, fallo = "Hay varias versiones")
  caso("eleccion_explicita_entre_versiones", varias = TRUE, explicito = TRUE)
  caso("rechaza_2026", transformar = function(x) { x$anio[16L] <- 2026L; x }, exito = FALSE, fallo = "Exactamente 16 anios")
  caso("rechaza_anio_faltante", transformar = function(x) x[-1L, ], exito = FALSE, fallo = "Exactamente 16 anios")
  caso("rechaza_anio_duplicado", transformar = function(x) { x$anio[2L] <- x$anio[1L]; x }, exito = FALSE, fallo = "Exactamente 16 anios")
  caso("rechaza_otro_trimestre", transformar = function(x) { x$trimestre[1L] <- "JAS"; x }, exito = FALSE, fallo = "Solo AMJ")
  caso("rechaza_columna_faltante", transformar = function(x) { x$tasa_ocupacion <- NULL; x }, exito = FALSE, fallo = "Esquema: CSV nacional")
  caso("rechaza_columnas_duplicadas", transformar = function(x) { names(x)[2L] <- names(x)[1L]; x }, exito = FALSE, fallo = "Columnas unicas")
  caso("rechaza_faltante_numerico", transformar = function(x) { x$tasa_ocupacion[1L] <- NA_real_; x }, exito = FALSE, fallo = "Sin faltantes ni valores no finitos")
  caso("rechaza_conteo_fraccionario", transformar = function(x) { x$n_muestra_pet[1L] <- x$n_muestra_pet[1L] + 0.5; x }, exito = FALSE, fallo = "Conteos muestrales enteros")
  caso("rechaza_poblacion_negativa", transformar = function(x) { x$ocupados_personas[1L] <- -1; x }, exito = FALSE, fallo = "Poblaciones y muestras no negativas")
  caso("rechaza_conteos_incompatibles", transformar = function(x) { x$n_muestra_pet[1L] <- x$n_muestra_pet[1L] + 1L; x }, exito = FALSE, fallo = "Reconciliacion de conteos muestrales")
  caso("rechaza_totales_incompatibles", transformar = function(x) { x$pet_personas[1L] <- x$pet_personas[1L] + 1; x }, exito = FALSE, fallo = "Reconciliacion poblacional")
  caso("rechaza_tasa_incompatible", transformar = function(x) { x$tasa_ocupacion[1L] <- x$tasa_ocupacion[1L] + 1; x }, exito = FALSE, fallo = "Tasas coinciden con razones de totales")
  caso("rechaza_denominador_cero", transformar = function(x) { x$fuerza_trabajo_personas[1L] <- 0; x }, exito = FALSE, fallo = "Denominadores positivos")
  caso("rechaza_conteo_auxiliar_negativo", auxiliar = "todos", modificar_aux = function(z) {
    z$controles$n_menores_15[1L] <- -1L; z$controles$n_total[1L] <- z$controles$n_pet[1L] - 1L; z
  }, exito = FALSE, fallo = "Controles 03 enteros no negativos")
  caso("rechaza_incidencias_auxiliares", auxiliar = "todos", modificar_aux = function(z) {
    z$controles$n_pet_peso_invalido[1L] <- 1L; z
  }, exito = FALSE, fallo = "Controles 03 sin incidencias")
  caso("rechaza_metadatos_cambiantes", auxiliar = "todos", modificar_aux = function(z) {
    k <- which(z$meta$variable == "activ")[1L]; z$meta$etiqueta_variable[k] <- "Etiqueta diferente"; z
  }, exito = FALSE, fallo = "Etiquetas constantes en metadatos: activ")
  caso("rechaza_contraste_incompatible", auxiliar = "todos", modificar_aux = function(z) {
    z$contraste$tasa_publicada[1L] <- z$contraste$tasa_publicada[1L] + 1; z$contraste$compatible_redondeo[1L] <- FALSE; z
  }, exito = FALSE, fallo = "Contraste provisto compatible con redondeo")
  caso("rechaza_contraste_de_otra_base", auxiliar = "todos", modificar_aux = function(z) {
    z$contraste$tasa_calculada[1L] <- z$contraste$tasa_calculada[1L] + 1; z
  }, exito = FALSE, fallo = "Contraste corresponde a tasas importadas")
  caso("limpia_productos_si_falla_grafico", png_falla = TRUE, exito = FALSE,
    fallo = "Fallo PNG inyectado exclusivamente para prueba")
  resumen <- do.call(rbind, resultado)
  escribir(resumen, file.path(destino, "pruebas_funcionales_06_01.csv"))
  texto <- c("# Verificacion funcional de 06.01", "",
    paste0("Runtime utilizado: ", R.version.string, "."),
    paste0("Pruebas ejecutadas: ", nrow(resumen), "; pasaron: ", sum(resumen$resultado == "PASA"),
      "; fallaron: ", sum(resumen$resultado == "FALLA"), "."), "",
    "Se uso una sesion nueva por caso. Se probaron Source desde otro directorio, ejecucion CLI, lectura sin objetos ene, exportacion y relectura CSV/RDS, cambios interanuales, PNG, auxiliares completos o ausentes, eleccion explicita de version y rechazo de entradas incompatibles.",
    "Se verifico conservacion de entradas mediante MD5 y ausencia de tablas/graficos tras las detenciones, incluida una falla PNG inyectada despues de exportar las tablas.", "",
    "Los datos fueron exclusivamente SINTETICOS bajo tempdir(). Se eliminaron sus fixtures y productos; no se copiaron cifras ni graficos de prueba al proyecto.",
    "Estos resultados prueban comportamiento del programa, NO resultados de la ENE, comparabilidad economica, fuentes oficiales ni ejecucion en Windows/RStudio. No se ejecutaron los scripts 01–05.", "",
    "Repetir: Rscript --vanilla work/verificacion/verificar_06_01.R /ruta/absoluta/proyecto")
  writeLines(enc2utf8(texto), file.path(destino, "LEEME_pruebas_funcionales_06_01.md"), useBytes = TRUE)
  if (any(resumen$resultado == "FALLA")) stop("Hay pruebas fallidas; consulte el informe funcional.")
  message("Verificacion completada: ", nrow(resumen), " pruebas funcionales satisfactorias con datos sinteticos.")
})
