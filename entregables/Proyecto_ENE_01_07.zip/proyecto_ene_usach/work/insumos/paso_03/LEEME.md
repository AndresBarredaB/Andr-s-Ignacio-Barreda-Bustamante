# Entrada del paso 06

Copie aqui el archivo real `indicadores_nacionales_AMJ_2010_2025.csv` del paso 03 y, si estan disponibles, `controles_por_anio.csv`, `metadatos_utilizados.csv`, `contraste_INE_2020_2025.csv`, `informe_nacional.md` y `sesion_R.txt` de la misma ejecucion. No cree datos ni renombre otros CSV para reemplazarlos.

Alternativa: copie la carpeta anterior a `outputs/resultados_indicadores_nacionales/`. Si hay mas de un CSV candidato, el script se detiene para que se indique uno con ENE_CSV_PASO03. No elige por fecha.
