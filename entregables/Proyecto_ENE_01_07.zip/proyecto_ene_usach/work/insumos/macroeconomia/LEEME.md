# Insumos macroeconomicos pendientes

Carpeta reservada para series y metadatos oficiales del Banco Central de Chile y del INE. No se descargaron ni verificaron series en esta ejecucion. No hay cifras macroeconomicas.

Registrar nombre y codigo verificados, URL real, unidad, frecuencia, ajuste estacional, base/referencia, cobertura, fecha de consulta y revisiones. PIB real y FBKF: proponer T2 y variacion interanual sobre volumen oficial. IPC: proponer promedio de las variaciones interanuales mensuales de abril, mayo y junio. Son decisiones propuestas, sujetas a verificacion de las series. Para calcular 2010 se necesitan antecedentes 2009; no amplian los 16 cortes del analisis.
