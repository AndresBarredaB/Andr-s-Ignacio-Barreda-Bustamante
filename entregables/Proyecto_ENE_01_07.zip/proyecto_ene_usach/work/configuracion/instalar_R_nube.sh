#!/bin/sh
# Solo para la nube Debian 13 amd64. No es necesario en Windows con RStudio/R.
# R base local; no modifica /usr, no instala paquetes R ni toca originales.
set -eu
ene_r_prefix=${ENE_R_PREFIX:-/workspace/.tools/ene-r}
ene_r_bin=${ENE_R_BIN:-/workspace/.tools/bin}
case "$ene_r_prefix:$ene_r_bin" in /*:/*) ;; *) echo 'Se requieren rutas absolutas.' >&2; exit 1;; esac
if [ -x "$ene_r_bin/Rscript" ]; then
  "$ene_r_bin/Rscript" --vanilla -e 'stopifnot(getRversion() >= "4.5.0", capabilities("png")); cat(R.version.string, "\n")'
  exit 0
fi
[ "$(dpkg --print-architecture)" = amd64 ] || { echo 'Requiere Debian amd64.' >&2; exit 1; }
[ -r /usr/share/keyrings/debian-archive-keyring.gpg ] || { echo 'Falta keyring Debian.' >&2; exit 1; }
ene_r_tmp=$(mktemp -d /tmp/ene-r-instalar.XXXXXX)
mkdir -p "$ene_r_tmp/lists/partial" "$ene_r_tmp/archives/partial" "$ene_r_prefix" "$ene_r_bin"
cat > "$ene_r_tmp/sources.list" <<'EOF'
deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://deb.debian.org/debian trixie main
EOF
cat > "$ene_r_tmp/apt.conf" <<EOF
Dir::Etc::parts "-";
Dir::Etc::main "/dev/null";
Dir::Etc::sourcelist "$ene_r_tmp/sources.list";
Dir::Etc::sourceparts "-";
Dir::State::lists "$ene_r_tmp/lists";
Dir::Cache::archives "$ene_r_tmp/archives";
EOF
# APT conserva validacion de firmas y hashes; TLS permanece habilitado.
APT_CONFIG="$ene_r_tmp/apt.conf" apt-get update
(cd "$ene_r_tmp/archives" && APT_CONFIG="$ene_r_tmp/apt.conf" apt-get download r-base-core=4.5.0-3)
dpkg-deb -x "$ene_r_tmp/archives/r-base-core_4.5.0-3_amd64.deb" "$ene_r_prefix"
python3 - "$ene_r_prefix" "$ene_r_bin" <<'PY'
from pathlib import Path
import shutil, sys, shlex
prefix, binpath = map(Path, sys.argv[1:])
etc = prefix / 'usr/lib/R/etc'
for path in etc.iterdir():
    if path.is_symlink():
        original = prefix / str(path.readlink()).lstrip('/')
        path.unlink()
        if original.exists():
            shutil.copy2(original, path)
        elif path.name == 'Renviron':
            shutil.copy2(etc / 'Renviron.ucf', path)
        else:
            raise RuntimeError(f'Falta configuracion {path}')
wrapper = prefix / 'usr/lib/R/bin/R'
text = wrapper.read_text().replace('R_HOME_DIR=/usr/lib/R', 'R_HOME_DIR=' + shlex.quote(str(prefix / 'usr/lib/R')), 1)
for kind, folder in [('SHARE', 'share'), ('INCLUDE', 'include'), ('DOC', 'doc')]:
    text = text.replace(f'R_{kind}_DIR=/usr/share/R/{folder}',
                        f'R_{kind}_DIR=' + shlex.quote(str(prefix / 'usr/share/R' / folder)), 1)
wrapper.write_text(text)
for name, dest in [('R', prefix / 'usr/lib/R/bin/R'), ('Rscript', prefix / 'usr/bin/Rscript')]:
    launcher = binpath / name
    launcher.write_text('#!/bin/sh\nexport RHOME=' + shlex.quote(str(prefix / 'usr/lib/R')) + '\nexec ' + shlex.quote(str(dest)) + ' "$@"\n')
    launcher.chmod(0o755)
PY
"$ene_r_bin/Rscript" --vanilla -e 'stopifnot(getRversion() >= "4.5.0", capabilities("png")); cat(R.version.string, "\n")'
echo "R base preparado en $ene_r_bin. Paquetes para etapas 01–05 no instalados."
