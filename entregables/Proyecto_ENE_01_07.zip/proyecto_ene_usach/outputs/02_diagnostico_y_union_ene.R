# Ejecutar en RStudio con Source. Requiere haven y vctrs.
# install.packages(c("haven", "vctrs"))
# Union de microdatos por filas, sin deduplicar ni calcular indicadores.
main <- function() {
  carpeta <- "C:/Users/andre/OneDrive/Escritorio/USACH-ING COMERCIAL/4 SEMESTRE/POLITICA ECONOMICA/BASES DE DATOS 2010-2026"
  salida <- file.path(getwd(), "resultados_union_ene")
  for (p in c("haven", "vctrs")) {
    if (!requireNamespace(p, quietly = TRUE))
      stop('Falta ', p, '. Ejecute install.packages(c("haven", "vctrs"))')
  }
  if (!dir.exists(carpeta)) stop("Carpeta de bases no accesible.")
  dir.create(salida, recursive = TRUE, showWarnings = FALSE)
  # Una subcarpeta nueva evita confundir resultados anteriores con esta ejecucion.
  corrida <- tempfile(pattern = paste0(format(Sys.time(), "%Y%m%d_%H%M%S"), "_"), tmpdir = salida)
  dir.create(corrida)
  csv <- function(x, nombre) write.csv(x, file.path(corrida, nombre),
    row.names = FALSE, na = "", fileEncoding = "UTF-8")
  archivos <- sort(list.files(carpeta, pattern = "\\.dta$", full.names = TRUE,
                             recursive = TRUE, ignore.case = TRUE))
  if (!length(archivos)) stop("No hay archivos .dta.")
  patron <- "^ene-([0-9]{4})-([0-9]{2})-([a-z]{3})( \\([0-9]+\\))?\\.dta$"
  nombres <- tolower(basename(archivos))
  reconocidos <- grepl(patron, nombres)
  if (!all(reconocidos)) stop("Nombres no reconocidos: ", paste(nombres[!reconocidos], collapse = ", "))
  anios <- as.integer(sub(patron, "\\1", nombres))
  trimestres <- sub(patron, "\\3", nombres)
  principal <- which(anios %in% 2010:2025)
  if (!setequal(anios[principal], 2010:2025) || anyDuplicated(anios[principal]))
    stop("Se requiere exactamente un archivo por anio de 2010 a 2025. Revise faltantes o duplicados.")
  if (length(unique(trimestres[principal])) != 1L)
    stop("Los archivos principales no tienen el mismo trimestre en el nombre.")
  requeridas <- c("edad", "sexo", "activ", "cae_especifico", "fact_cal")
  reservadas <- c("ene_anio_origen", "ene_trimestre_origen", "ene_archivo_origen", "ene_fila_origen")
  inventario <- list(); diccionario <- list(); atributos <- list()
  # Primera pasada: diagnostico y atributos exactos, sin acumular microdatos.
  familia <- function(x) {
    if (inherits(x, "Date")) return("fecha")
    if (inherits(x, "POSIXct")) return("fecha_hora")
    if (inherits(x, "haven_labelled")) x <- haven::zap_labels(x)
    if (is.object(x)) stop("Clase no soportada: ", paste(class(x), collapse = "/"))
    switch(typeof(x), integer = "numerica", double = "numerica",
      character = "texto", logical = "logica", stop("Tipo no soportado: ", typeof(x)))
  }
  texto_attr <- function(x) paste(capture.output(dput(x)), collapse = " ")
  for (i in seq_along(archivos)) {
    message("Diagnostico: ", basename(archivos[i]))
    error <- ""; avisos <- character()
    d <- tryCatch(withCallingHandlers(haven::read_dta(archivos[i], .name_repair = "minimal"),
      warning = function(w) { avisos <<- c(avisos, conditionMessage(w)); invokeRestart("muffleWarning") }),
      error = function(e) { error <<- conditionMessage(e); NULL })
    fila <- data.frame(archivo = basename(archivos[i]), ruta = archivos[i], anio = anios[i],
      trimestre_nombre = trimestres[i], principal = i %in% principal,
      filas = if (is.null(d)) NA_integer_ else nrow(d),
      columnas = if (is.null(d)) NA_integer_ else ncol(d), error = error,
      advertencias = paste(avisos, collapse = " | "))
    for (v in requeridas) fila[[paste0("existe_", v)]] <- if (is.null(d)) NA else v %in% names(d)
    inventario[[i]] <- fila
    if (!is.null(d)) {
      if (anyDuplicated(names(d)) || any(names(d) %in% reservadas))
        stop("Nombres duplicados o reservados en ", basename(archivos[i]))
      atributos[[archivos[i]]] <- lapply(d, attributes)
      diccionario[[i]] <- data.frame(archivo = basename(archivos[i]), anio = anios[i],
        variable = names(d), tipo_R = vapply(d, typeof, character(1)),
        clase_R = vapply(d, function(x) paste(class(x), collapse = ";"), character(1)),
        familia = vapply(d, familia, character(1)),
        etiqueta_variable = vapply(d, function(x) texto_attr(attr(x, "label")), character(1)),
        etiquetas_valores = vapply(d, function(x) texto_attr(attr(x, "labels")), character(1)))
    }
    rm(d); invisible(gc())
  }
  inv <- do.call(rbind, inventario)
  dic <- do.call(rbind, diccionario)
  csv(inv, "inventario_todos.csv")
  csv(inv[inv$principal, ], "inventario_2010_2025.csv")
  csv(inv[inv$anio == 2026, ], "inventario_2026.csv")
  csv(dic, "diccionario_por_anio.csv")
  saveRDS(atributos, file.path(corrida, "atributos_originales_por_archivo.rds"))
  if (any(inv$error[inv$principal] != ""))
    stop("Error al leer una base principal. Revise inventario_todos.csv en ", corrida)
  dp <- dic[dic$anio %in% 2010:2025, ]
  resumen <- do.call(rbind, lapply(split(dp, dp$variable), function(z) {
    data.frame(variable = z$variable[1], anios_presente = length(unique(z$anio)),
      anios_ausente = paste(setdiff(2010:2025, z$anio), collapse = ";"),
      tipos_R = paste(sort(unique(z$tipo_R)), collapse = ";"),
      familias = paste(sort(unique(z$familia)), collapse = ";"),
      tipos_incompatibles = length(unique(z$familia)) > 1L,
      cambia_clase = length(unique(z$clase_R)) > 1L,
      cambia_etiqueta_variable = length(unique(z$etiqueta_variable)) > 1L,
      cambia_etiquetas_valores = length(unique(z$etiquetas_valores)) > 1L)
  }))
  csv(resumen, "compatibilidad_variables.csv")
  # Tipos incompatibles: conservar columnas separadas por familia, sin coercion.
  conflictos <- resumen$variable[resumen$tipos_incompatibles]
  dp$variable_salida <- ifelse(dp$variable %in% conflictos,
    paste0(dp$variable, "__", dp$familia), dp$variable)
  mapa <- unique(dp[c("variable", "familia", "variable_salida")])
  if (anyDuplicated(mapa$variable_salida)) stop("Colision de nombres al separar tipos; revise diccionario.")
  csv(dp[c("archivo", "anio", "variable", "familia", "variable_salida")], "mapa_columnas_union.csv")
  limpio <- function(x) {
    # Etiquetas por anio permanecen en el diccionario y RDS de atributos.
    # No se asigna a todos los anios la etiqueta de una sola base.
    if (inherits(x, "haven_labelled")) x <- haven::zap_labels(x)
    attr(x, "label") <- NULL
    attr(x, "format.stata") <- NULL
    x
  }
  bases <- vector("list", length(principal))
  for (k in seq_along(principal)) {
    i <- principal[k]
    message("Preparando union: ", basename(archivos[i]))
    d <- haven::read_dta(archivos[i])
    if (nrow(d) != inv$filas[i] || !identical(names(d), diccionario[[i]]$variable))
      stop("El archivo cambio entre lectura y union: ", archivos[i])
    f <- vapply(d, familia, character(1))
    names(d) <- ifelse(names(d) %in% conflictos, paste0(names(d), "__", f), names(d))
    d[] <- lapply(d, limpio)
    d$ene_anio_origen <- rep(anios[i], nrow(d))
    d$ene_trimestre_origen <- rep(trimestres[i], nrow(d))
    d$ene_archivo_origen <- rep(basename(archivos[i]), nrow(d))
    d$ene_fila_origen <- seq_len(nrow(d))
    bases[[k]] <- d
  }
  # vec_rbind rellena con NA las variables que no existen en algunos anios.
  unificada <- do.call(vctrs::vec_rbind, bases)
  esperadas <- sum(inv$filas[inv$principal])
  stopifnot(nrow(unificada) == esperadas)
  control <- as.data.frame(table(unificada$ene_anio_origen), stringsAsFactors = FALSE)
  names(control) <- c("anio", "filas_unificadas")
  control$filas_originales <- inv$filas[match(as.integer(as.character(control$anio)), inv$anio)]
  stopifnot(all(control$filas_unificadas == control$filas_originales))
  csv(control, "control_filas_union.csv")
  saveRDS(unificada, file.path(corrida, "ene_2010_2025_union_tecnica.rds"), compress = FALSE)
  capture.output(sessionInfo(), file = file.path(corrida, "sesion_R.txt"))
  message("Union terminada: ", nrow(unificada), " filas y ", ncol(unificada), " columnas.")
  message("Resultados: ", normalizePath(corrida, winslash = "/"))
  message("Esta union tecnica requiere revisar etiquetas y definiciones antes de calcular indicadores.")
  invisible(corrida)
}
ruta_resultados_ene <- main()
