# Verificacion funcional de 06.01

Runtime utilizado: R version 4.5.0 (2025-04-11).
Pruebas ejecutadas: 25; pasaron: 25; fallaron: 0.

Se uso una sesion nueva por caso. Se probaron Source desde otro directorio, ejecucion CLI, lectura sin objetos ene, exportacion y relectura CSV/RDS, cambios interanuales, PNG, auxiliares completos o ausentes, eleccion explicita de version y rechazo de entradas incompatibles.
Se verifico conservacion de entradas mediante MD5 y ausencia de tablas/graficos tras las detenciones, incluida una falla PNG inyectada despues de exportar las tablas.

Los datos fueron exclusivamente SINTETICOS bajo tempdir(). Se eliminaron sus fixtures y productos; no se copiaron cifras ni graficos de prueba al proyecto.
Estos resultados prueban comportamiento del programa, NO resultados de la ENE, comparabilidad economica, fuentes oficiales ni ejecucion en Windows/RStudio. No se ejecutaron los scripts 01–05.

Repetir: Rscript --vanilla work/verificacion/verificar_06_01.R /ruta/absoluta/proyecto
