# 07 — Politicas de empleo y estrategia econometrica defendible.
# Ejecutar el archivo completo con Source en RStudio o con Rscript --vanilla.
# R base; no instala paquetes, no descarga fuentes ni ejecuta etapas anteriores.
# Trabaja con documentos persistidos y distingue candidatas de fuentes leidas.
local({
  # 1. RUTAS: se derivan del archivo ejecutado, nunca del directorio de trabajo.
  absoluta <- function(x) grepl("^(/|[A-Za-z]:[/\\\\]|\\\\\\\\)", x)
  raiz_configurada <- Sys.getenv("ENE_PROYECTO", unset = "")
  if (nzchar(raiz_configurada)) {
    if (!absoluta(raiz_configurada) || !dir.exists(raiz_configurada))
      stop("ENE_PROYECTO debe ser una carpeta absoluta existente.", call. = FALSE)
    raiz <- normalizePath(raiz_configurada, winslash = "/", mustWork = TRUE)
  } else {
    ofiles <- Filter(function(x) is.character(x) && length(x) == 1L,
      lapply(sys.frames(), function(f) f$ofile))
    cli <- grep("^--file=", commandArgs(), value = TRUE)
    archivo <- if (length(ofiles)) tail(ofiles, 1L)[[1L]] else
      if (length(cli) == 1L) sub("^--file=", "", cli) else ""
    if (!nzchar(archivo) || !file.exists(archivo))
      stop("Ejecute el archivo completo con Source/Rscript o defina ENE_PROYECTO.", call. = FALSE)
    raiz <- dirname(dirname(normalizePath(archivo, winslash = "/", mustWork = TRUE)))
  }
  insumos <- file.path(raiz, "work", "insumos", "paso_07")
  salida_raiz <- file.path(raiz, "outputs", "resultados_07_politicas_empleo")
  if (!dir.exists(salida_raiz) && !dir.create(salida_raiz, recursive = TRUE))
    stop("No se pudo crear la salida del paso 07.")
  salida <- tempfile(paste0("07_", format(Sys.time(), "%Y%m%d_%H%M%S"), "_"), tmpdir = salida_raiz)
  if (!dir.create(salida)) stop("No se pudo crear una ejecucion nueva.")
  for (p in c("tablas", "graficos", "documentacion", "controles"))
    if (!dir.create(file.path(salida, p))) stop("No se pudo crear: ", p)

  ejecutar <- function() {
    registro <- data.frame(control = character(), estado = character(), detalle = character())
    guardar <- function(x, carpeta, nombre) write.csv(x, file.path(salida, carpeta, nombre),
      row.names = FALSE, na = "", fileEncoding = "UTF-8")
    anotar <- function(nombre, estado, detalle = "") registro <<- rbind(registro,
      data.frame(control = nombre, estado = estado, detalle = detalle))
    comprobar <- function(x, nombre, detalle = "") {
      ok <- isTRUE(x)
      anotar(nombre, if (ok) "PASA" else "FALLA", detalle)
      if (!ok) stop(nombre, if (nzchar(detalle)) paste0(": ", detalle), call. = FALSE)
    }
    no_vacio <- function(x) !is.na(x) & nzchar(trimws(x))
    leer <- function(nombre, columnas) {
      f <- file.path(insumos, nombre)
      comprobar(file.exists(f), paste0("Entrada disponible: ", nombre), f)
      x <- read.csv(f, stringsAsFactors = FALSE, check.names = FALSE,
        colClasses = "character", fileEncoding = "UTF-8-BOM", na.strings = c("", "NA"))
      comprobar(!anyDuplicated(names(x)), paste0("Nombres unicos: ", nombre))
      comprobar(all(columnas %in% names(x)), paste0("Esquema: ", nombre),
        paste(setdiff(columnas, names(x)), collapse = ", "))
      x[] <- lapply(x, function(z) { z[is.na(z)] <- ""; trimws(z) })
      x
    }
    fecha_iso <- function(x) {
      fechas <- suppressWarnings(as.Date(x, format = "%Y-%m-%d"))
      !is.na(fechas) & grepl("^[0-9]{4}-[0-9]{2}-[0-9]{2}$", x) & format(fechas, "%Y-%m-%d") == x
    }
    finalizar <- function(estado, texto) {
      guardar(registro, "controles", "validaciones_07.csv")
      capture.output(sessionInfo(), file = file.path(salida, "documentacion", "sesion_R_07.txt"))
      writeLines(enc2utf8(c(paste0("Estado: ", estado), texto,
        paste0("Proyecto: ", raiz), paste0("Ejecucion: ", normalizePath(salida, winslash = "/")))),
        file.path(salida, "documentacion", "estado_07.txt"), useBytes = TRUE)
      message("Paso 07: ", estado, "\nCarpeta: ", normalizePath(salida, winslash = "/"))
    }

    tryCatch({
      # 2. ENTRADAS CURADAS: tener un nombre de archivo no acredita verificacion.
      pol <- leer("politicas_documentadas.csv", c("politica_id", "politica", "norma_o_instrumento",
        "fecha_hito", "precision_fecha", "tipo_hito", "poblacion_objetivo", "mecanismo", "fuente_id", "alcance"))
      ev <- leer("evidencia_evaluaciones.csv", c("evidencia_id", "politica_id", "titulo_evaluacion",
        "institucion", "anio_documento", "tipo_evaluacion", "diseno_reportado", "hallazgo_documentado",
        "limite_inferencia", "fuente_id"))
      fuentes <- leer("fuentes_verificadas.csv", c("fuente_id", "institucion", "titulo", "url",
        "fecha_consulta", "archivo_local", "sha256", "estado_verificacion", "extracto_verificado"))
      estrategia <- leer("estrategia_econometrica.csv", c("estrategia_id", "pregunta", "diseno",
        "estimando_o_descripcion", "factibilidad_actual", "requisitos", "supuestos_y_riesgos", "decision"))
      comprobar(nrow(pol) > 0L && all(no_vacio(pol$politica_id) & no_vacio(pol$politica)), "Lista de politicas identificada")
      comprobar(nrow(fuentes) > 0L && all(no_vacio(fuentes$fuente_id)) && !anyDuplicated(fuentes$fuente_id),
        "Fuentes con ID unicos")
      comprobar(!anyDuplicated(pol[c("politica_id", "fecha_hito", "tipo_hito")]), "Hitos no duplicados")
      comprobar(!anyDuplicated(ev$evidencia_id) && all(no_vacio(ev$evidencia_id)), "Evaluaciones con ID unicos")
      comprobar(all(pol$fuente_id %in% fuentes$fuente_id) && all(ev$fuente_id %in% fuentes$fuente_id) &&
        all(ev$politica_id %in% pol$politica_id), "Referencias entre politicas, evaluaciones y fuentes")
      comprobar(nrow(estrategia) >= 6L && !anyDuplicated(estrategia$estrategia_id) &&
        all(no_vacio(estrategia$estrategia_id)), "Estrategias identificadas")
      comprobar(all(grepl("^https://", fuentes$url)), "URLs de referencia HTTPS")
      f_entrada <- file.path(insumos, c("politicas_documentadas.csv", "evidencia_evaluaciones.csv",
        "fuentes_verificadas.csv", "estrategia_econometrica.csv"))
      guardar(data.frame(ruta = normalizePath(f_entrada, winslash = "/"),
        md5 = unname(tools::md5sum(f_entrada))), "controles", "procedencia_entradas.csv")

      # 3. SOPORTE LOCAL DE CADA FUENTE. No se consultan ni aprueban paginas aqui.
      # R base registra MD5; SHA256 es el hash aportado por la revision externa.
      auditoria <- fuentes[c("fuente_id", "estado_verificacion", "archivo_local", "sha256")]
      auditoria$archivo_existente <- FALSE
      auditoria$archivo_dentro_proyecto <- FALSE
      auditoria$md5_observado <- ""
      auditoria$soporte_documental_local <- FALSE
      auditoria$fecha_corresponde_a_lectura <- FALSE
      for (i in seq_len(nrow(fuentes))) {
        f <- fuentes[i, ]
        ruta <- if (no_vacio(f$archivo_local)) {
          if (absoluta(f$archivo_local)) f$archivo_local else file.path(raiz, f$archivo_local)
        } else ""
        existe <- nzchar(ruta) && file.exists(ruta) && !dir.exists(ruta)
        dentro <- FALSE
        if (existe) {
          normal <- normalizePath(ruta, winslash = "/", mustWork = TRUE)
          dentro <- startsWith(tolower(normal), paste0(tolower(raiz), "/"))
        }
        auditoria$archivo_existente[i] <- existe
        auditoria$archivo_dentro_proyecto[i] <- dentro
        if (existe && dentro) auditoria$md5_observado[i] <- unname(tools::md5sum(ruta))
        leida <- toupper(f$estado_verificacion) == "LEIDA"
        soporte <- leida && existe && dentro && grepl("^[a-fA-F0-9]{64}$", f$sha256) &&
          no_vacio(f$extracto_verificado) && isTRUE(fecha_iso(f$fecha_consulta))
        auditoria$soporte_documental_local[i] <- soporte
        auditoria$fecha_corresponde_a_lectura[i] <- leida && soporte
        anotar(paste0("Soporte de fuente: ", f$fuente_id), if (soporte) "DISPONIBLE" else "PENDIENTE",
          if (soporte) "Documento local y metadatos presentes; SHA256 registrado, no recalculado en R." else
            "No se utiliza como evidencia verificada. Una fecha de intento no acredita consulta del contenido.")
      }
      guardar(auditoria, "controles", "auditoria_fuentes.csv")
      fuente_ok <- setNames(auditoria$soporte_documental_local, fuentes$fuente_id)
      pol$fuente_utilizable <- unname(fuente_ok[pol$fuente_id])
      ev$fuente_utilizable <- unname(fuente_ok[ev$fuente_id])

      # 4. FECHAS: solo hitos documentados. No se inventan inicios ni duraciones.
      pol$precision_fecha <- toupper(iconv(pol$precision_fecha, to = "ASCII//TRANSLIT"))
      tiene_fecha <- no_vacio(pol$fecha_hito)
      comprobar(all(!pol$fuente_utilizable | tiene_fecha), "Fuentes utilizables exigen fecha del hito")
      comprobar(all(!tiene_fecha | fecha_iso(pol$fecha_hito)), "Fechas de hitos ISO validas cuando se aportan")
      comprobar(all(!tiene_fecha | pol$precision_fecha %in% c("DIA", "MES", "ANIO", "ANO")), "Precision explicita de fechas aportadas")
      comprobar(all(tiene_fecha | !pol$fuente_utilizable), "Sin fuente utilizable: fecha puede quedar pendiente")
      comprobar(all(!tiene_fecha | as.integer(substr(pol$fecha_hito, 1L, 4L)) <= 2025L), "Hitos hasta 2025; 2026 separado")
      comprobar(all(!tiene_fecha | pol$precision_fecha != "MES" | substr(pol$fecha_hito, 9L, 10L) == "01") &&
        all(!tiene_fecha | !pol$precision_fecha %in% c("ANIO", "ANO") | substr(pol$fecha_hito, 6L, 10L) == "01-01"),
        "Fechas aproximadas codificadas sin precision ficticia", "MES usa dia01; ANIO enero01 solo como codificacion.")
      pol$hito_documentado <- pol$fuente_utilizable & tiene_fecha
      pol$fecha_presentada <- "PENDIENTE DE DOCUMENTAR"
      for (i in which(tiene_fecha)) pol$fecha_presentada[i] <-
        if (pol$precision_fecha[i] == "DIA") pol$fecha_hito[i] else
          if (pol$precision_fecha[i] == "MES") substr(pol$fecha_hito[i], 1L, 7L) else substr(pol$fecha_hito[i], 1L, 4L)
      pol$estado_documentacion <- ifelse(pol$hito_documentado, "HITO_DOCUMENTADO_CON_SOPORTE_LOCAL", "CANDIDATA_PENDIENTE_DE_DOCUMENTAR")
      comprobar(all(no_vacio(ev$limite_inferencia) & no_vacio(ev$tipo_evaluacion) & no_vacio(ev$diseno_reportado)) || !nrow(ev),
        "Evaluaciones distinguen diseno y limites de inferencia")
      if (nrow(ev)) {
        comprobar(all(grepl("^[0-9]{4}$", ev$anio_documento) & as.integer(ev$anio_documento) >= 1900L &
          as.integer(ev$anio_documento) <= as.integer(format(Sys.Date(), "%Y"))),
          "Anio documental valido", "Una evaluacion posterior puede estudiar politicas historicas; no agrega datos laborales de 2026.")
        ev$hallazgo_utilizable <- ifelse(ev$fuente_utilizable, ev$hallazgo_documentado,
          "PENDIENTE: no utilizar este hallazgo sin fuente leida y soporte local.")
      } else ev$hallazgo_utilizable <- character()
      # El informe solo incorpora hallazgos de fuentes utilizables, nunca los pendientes.

      # 5. INVENTARIO EMPIRICO: presencia no significa que una tabla este validada.
      buscar <- function(tipo, carpetas, patron) {
        rutas <- unique(as.character(unlist(lapply(carpetas, function(p) {
          if (dir.exists(p)) list.files(p, pattern = patron, full.names = TRUE, recursive = TRUE) else character()
        }), use.names = FALSE)))
        if (!length(rutas)) data.frame(insumo = tipo, ruta = "", estado = "NO_RECIBIDO") else
          data.frame(insumo = tipo, ruta = normalizePath(rutas, winslash = "/"),
            estado = if (length(rutas) > 1L) "VARIAS_VERSIONES_NO_SELECCIONADAS" else "PRESENTE_NO_VALIDADO_EN_07")
      }
      inventario <- do.call(rbind, list(
        buscar("CSV nacional 03", file.path(raiz, c("work/insumos/paso_03", "outputs/resultados_indicadores_nacionales")),
          "^indicadores_nacionales_AMJ_2010_2025[.]csv$"),
        buscar("Tablas sexo y edad 04", file.path(raiz, "outputs/resultados_04_sexo_edad"), "^tablas_04[.]rds$"),
        buscar("Tablas sectores 05", file.path(raiz, "outputs/resultados_05_sectores"), "^tablas_05[.]rds$"),
        buscar("Base laboral preparada 06", file.path(raiz, "outputs/resultados_06_contexto_macroeconomico"),
          "^base_laboral_AMJ_2010_2025[.]csv$")))
      guardar(inventario, "controles", "inventario_insumos_empiricos.csv")

      # 6. TABLAS Y GRAFICO. Candidatas y cronologia verificada quedan separadas.
      cronologia <- pol[pol$hito_documentado, ]
      if (nrow(cronologia)) cronologia <- cronologia[order(cronologia$fecha_hito, cronologia$politica), ]
      candidatas <- pol[!pol$hito_documentado, ]
      evidencia_util <- ev[ev$fuente_utilizable, ]
      guardar(cronologia, "tablas", "cronologia_hitos_documentados.csv")
      guardar(candidatas, "tablas", "politicas_candidatas_PENDIENTES.csv")
      guardar(evidencia_util, "tablas", "evidencia_evaluaciones_con_soporte.csv")
      guardar(estrategia, "tablas", "estrategia_econometrica.csv")
      guardar(fuentes, "tablas", "registro_estado_fuentes.csv")
      saveRDS(list(cronologia = cronologia, candidatas = candidatas, evidencia = evidencia_util,
        estrategia = estrategia, fuentes = fuentes, auditoria = auditoria, insumos_empiricos = inventario),
        file.path(salida, "tablas", "tablas_07.rds"))
      png(file.path(salida, "graficos", "01_estado_cronologia_politicas.png"), width = 2100, height = 1250, res = 180)
      dispositivo <- dev.cur()
      tryCatch({
        par(mar = c(5, 14, 4, 2), bg = "white", col.axis = "#334155", col.lab = "#334155", las = 1)
        if (nrow(cronologia)) {
          fechas <- as.Date(cronologia$fecha_hito)
          limites <- range(fechas) + c(-100, 100)
          plot(fechas, seq_along(fechas), pch = 19, cex = 1.2, col = "#147D92", xlim = limites,
            ylim = c(0.5, length(fechas) + 0.5), yaxt = "n", xaxt = "n", xlab = "Fecha del hito documental",
            ylab = "", main = "Politicas de empleo: hitos con soporte documental")
          axis(2, at = seq_along(fechas), labels = cronologia$politica, cex.axis = 0.7)
          axis.Date(1, at = pretty(fechas), format = "%Y")
          text(fechas, seq_along(fechas), labels = cronologia$fecha_presentada, pos = 3, cex = 0.65, col = "#203B52")
          mtext("Puntos: hitos, no periodos de vigencia ni tratamiento efectivo. Ver precision y tipo de hito en tablas.",
            side = 1, line = 3, cex = 0.65)
        } else {
          par(mar = c(2, 2, 3, 2))
          plot.new()
          title("Cronologia de politicas: documentacion pendiente", col.main = "#203B52")
          text(0.5, 0.72, "No hay hitos verificados para representar.", cex = 1.1, col = "#A14470")
          text(0.5, 0.57, paste(strwrap(paste0(nrow(candidatas),
            " politicas candidatas registradas. Falta leer fuentes oficiales y verificar normas, fechas, poblacion objetivo y mecanismos."), width = 72), collapse = "\n"), cex = 0.95, col = "#334155")
          text(0.5, 0.31, "Esta lamina informa una limitacion; no es una cronologia ni un resultado economico.",
            cex = 0.8, col = "#334155")
        }
      }, finally = dev.off(dispositivo))

      # 7. INFORME: separar progreso metodologico de resultados aun no obtenidos.
      fuentes_pendientes <- sum(!auditoria$soporte_documental_local)
      estado <- if (!nrow(cronologia) && !nrow(evidencia_util)) "REVISION_DOCUMENTAL_PENDIENTE" else
        if (fuentes_pendientes) "REVISION_DOCUMENTAL_PARCIAL" else "REVISION_DOCUMENTAL_CON_SOPORTE_LOCAL"
      informe <- c("# 07. Politicas de empleo y estrategia econometrica", "",
        paste0("Estado: **", estado, "**"), "",
        "## Que se realizo y que significan los productos",
        "Se leyeron los CSV persistidos, se revisaron esquemas y referencias, se registro el soporte local de las fuentes y se produjo una matriz de decisiones econometricas. No se consultan paginas ni se ejecutan regresiones en este programa.",
        sprintf("Productos documentales: %d politicas candidatas pendientes, %d hitos con soporte local y %d evaluaciones utilizables. Estos conteos son inventario documental, no poblaciones laborales.",
          nrow(candidatas), nrow(cronologia), nrow(evidencia_util)),
        "El archivo de entrada fuentes_verificadas.csv es un registro de estados: su nombre NO significa que todas las fuentes esten leidas. El estado LEIDA requiere documento cacheado dentro del proyecto, extracto, fecha y SHA256 registrado. R registra MD5 observado y no recalcula SHA256 ni certifica la calidad de la lectura.",
        "Cuando el acceso esta pendiente, fecha_consulta puede identificar un intento fallido, no la lectura del contenido. Consulte auditoria_fuentes.csv. No se usan fuentes pendientes para fechar politicas o sostener hallazgos.", "",
        "## Politicas candidatas por investigar",
        if (nrow(candidatas)) paste0("- ", candidatas$politica, ": candidata; requisitos, fechas y mecanismo por documentar.") else
          "Las candidatas disponen de hitos con soporte local; deben conservarse los limites de cada documento.", "",
        "## Cronologia y evidencia de evaluaciones")
      if (!nrow(cronologia)) informe <- c(informe,
        "No se produjo una cronologia verificada: la tabla correspondiente tiene solo encabezados y el PNG explica la limitacion. No se inventan fechas ni periodos de vigencia.") else
          informe <- c(informe, paste0("- ", cronologia$fecha_presentada, ": ", cronologia$politica,
            " | ", cronologia$tipo_hito, " | fuente: ", cronologia$fuente_id, "."))
      if (!nrow(evidencia_util)) informe <- c(informe,
        "No se incorporaron hallazgos de evaluaciones leidas. Esto NO demuestra que no existan evaluaciones o efectos: la revision de fuentes esta pendiente.") else
          informe <- c(informe, unlist(lapply(seq_len(nrow(evidencia_util)), function(i) {
            e <- evidencia_util[i, ]
            c(paste0("- ", e$titulo_evaluacion, " (", e$institucion, ", ", e$anio_documento, "): ", e$hallazgo_utilizable),
              paste0("  Diseno reportado: ", e$diseno_reportado, ". Limite: ", e$limite_inferencia, " Fuente: ", e$fuente_id, "."))
          })))
      informe <- c(informe, "", "## Estrategia econometrica y alcance",
        "La muestra temporal principal tiene 16 cortes AMJ 2010–2025. No es una serie de promedios anuales ni un panel de personas. Los cambios describen grupos y agregados. 2026 queda separado.",
        "La estrategia actual es descriptiva. Una correlacion o coincidencia temporal no identifica el efecto causal de una politica. La recuperacion de un indicador tampoco identifica que personas recuperaron su empleo.",
        "Con los insumos actuales, no se estiman modelos: falta validar los productos laborales y las series macroeconomicas. Tampoco se crean dummies de tratamiento a partir del sexo/edad ni de la fecha de una politica.",
        "La matriz enumera disenos, requisitos y decisiones. Una eventual relacion de Okun bivariada seria exploratoria y en variaciones compatibles; con 16 cortes y a lo sumo 15 cambios consecutivos tendria baja potencia y sensibilidad a pandemia y revisiones. No se estima ni se selecciona por significancia aqui.",
        "Sin un dato laboral adicional de 2009, el cambio de desocupacion entre AMJ consecutivos deja 15 observaciones, 2011–2025; no 16. El signo de la asociacion con el crecimiento se examinaria sin imponerlo como restriccion.",
        "Desagregar por sexo y edad no crea mas variacion macroeconomica independiente: se mantienen 16 anios. Tampoco justifica errores estandar de muchos clusters cuando los shocks comunes solo varian por esos pocos anios. Las varianzas de cambios requieren considerar covarianzas; no se reconstruyen a partir de los IC marginales de04 suponiendo independencia.",
        "DID requiere exposicion real o elegibilidad verificable, un grupo de comparacion defendible, preperiodos y supuestos sobre tendencias paralelas y shocks concurrentes. Edad/sexo por si solos no identifican beneficiarios. RDD exige regla y puntaje exactos, continuidad y ausencia de manipulacion; no se presupone exogeneidad de un umbral.",
        "Ampliar a una frecuencia trimestral seria una propuesta posterior que exige documentacion y cobertura comparables. No se cambia aqui el alcance ni se cuentan trimestres moviles solapados como observaciones independientes.", "",
        "## Interpretacion tecnica",
        "La revision documental y el diseno de identificacion son productos distintos de una estimacion. La identificacion causal exige un contrafactual; la ENE transversal repetida con ponderadores y un calendario de programas no lo proporcionan automaticamente. La inferencia laboral debe respetar el diseno muestral. Los sectores conservan tres bloques; no se impone una serie sectorial homogenea.",
        "## Interpretacion sencilla",
        "Podemos organizar que politicas investigar y explicar que datos harian falta para evaluarlas. Ver que el desempleo baja despues de una medida no prueba que la medida lo haya causado: tambien pueden cambiar la economia, la participacion o la composicion de la poblacion.", "",
        "## Conclusiones de politica economica condicionadas",
        "No hay fundamento en esta entrega para afirmar que una politica funciono o fracaso, ni para atribuir los cambios al bajo crecimiento. La recomendacion metodologica es verificar fuentes y beneficiarios, leer las evaluaciones segun su diseno y triangular empleo, desocupacion y participacion antes de formular conclusiones sustantivas.",
        "Una evaluacion de gestion/cobertura no equivale a una de impacto. Un efecto estimado para beneficiarios elegibles en un periodo no se extrapola automaticamente al desempleo nacional ni a todas las mujeres o personas jovenes.", "",
        "## Insumos empiricos y pendientes",
        "inventario_insumos_empiricos.csv registra presencia o ausencia. Un archivo presente no queda validado por el paso 07; varias versiones no se seleccionan automaticamente. No se ejecutaron 01–05 ni se leyeron objetos ene de Environment.",
        "Proximo paso: habilitar acceso y leer las fuentes oficiales; documentar fecha real, instrumento, requisitos, mecanismo y evaluaciones. Despues incorporar el CSV03 y controles de la misma ejecucion, validar06 y completar fuentes macroeconomicas antes de decidir una estimacion.", "",
        "## Ejecucion y ubicacion",
        paste0("Raiz verificada: `", raiz, "`. Salida: `", normalizePath(salida, winslash = "/"), "`."),
        "El programa es reproducible con Source completo o Rscript en sesion nueva; usa R base. Cada ejecucion crea una carpeta nueva y conserva entradas y productos anteriores.")
      writeLines(enc2utf8(informe), file.path(salida, "documentacion", "informe_07_politicas_y_estrategia.md"), useBytes = TRUE)
      guardar(data.frame(estado = estado, fuentes_pendientes = fuentes_pendientes,
        politicas_candidatas = nrow(candidatas), hitos_documentados = nrow(cronologia),
        evaluaciones_con_soporte = nrow(evidencia_util), modelos_estimados = 0L), "controles", "resumen_estado_07.csv")
      finalizar(estado, "Productos metodologicos generados; resultados empiricos y conclusiones sustantivas requieren insumos y fuentes verificadas.")
      invisible(salida)
    }, error = function(e) {
      unlink(list.files(file.path(salida, "tablas"), full.names = TRUE))
      unlink(list.files(file.path(salida, "graficos"), full.names = TRUE))
      anotar("Ejecucion", "DETENIDA", conditionMessage(e))
      finalizar("DETENIDO_SIN_PRODUCTOS_DOCUMENTALES", conditionMessage(e))
      stop(conditionMessage(e), call. = FALSE)
    })
  }
  ejecutar()
})
