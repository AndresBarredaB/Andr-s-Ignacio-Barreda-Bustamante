# Carpeta reservada para resultados anteriores

Creada en esta nube para organizar el proyecto. NO contiene resultados estadisticos originales: todavia no fueron adjuntados ni se ejecutaron las etapas 01–05.

Los scripts originales se conservaron sin cambios. Al ejecutarlos, su salida depende de getwd(); crear esta carpeta no cambia ese comportamiento. No ejecute 01–05 para comenzar 06 si ya tiene productos utilizables.
