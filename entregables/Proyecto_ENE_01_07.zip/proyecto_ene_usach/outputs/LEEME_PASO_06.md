# Inicio del paso 06 — contexto macroeconomico

## Archivos y carpetas creados

Los cinco scripts adjuntos estan en `outputs/`, conservados byte a byte. Se leyeron completos, pero no se ejecutaron 01–05. Las carpetas reservadas para sus resultados incluyen un LEEME que indica que aun no se recibieron los productos originales.

```text
CONTEXTO_PROYECTO.md
outputs/
  01_inventario_ene.R
  02_diagnostico_y_union_ene.R
  03_indicadores_laborales_nacionales.R
  04_indicadores_laborales_sexo_edad.R
  05_empleo_sectores_productivos.R
  06_01_preparar_base_laboral_AMJ.R
  LEEME_PASO_06.md
  resultados_ene/
  resultados_union_ene/
  resultados_indicadores_nacionales/
  resultados_04_sexo_edad/
  resultados_05_sectores/
  resultados_06_contexto_macroeconomico/
    00_revision_insumos/
    ejecuciones/<identificador_nuevo>/
      controles/
      documentacion/
      tablas/
      graficos/
work/
  insumos/paso_03/
  insumos/macroeconomia/
  configuracion/instalar_R_nube.sh
  verificacion/
```

## Que hace el primer bloque

`06_01_preparar_base_laboral_AMJ.R` usa exclusivamente R base y archivos persistidos. Detecta su carpeta desde el archivo ejecutado, sin `file.choose()`, sin depender del directorio de trabajo y sin reutilizar un objeto `ene` cargado previamente. No requiere leer la union de varios GB para revisar el CSV nacional.

Busca `indicadores_nacionales_AMJ_2010_2025.csv` en dos ubicaciones explicitas dentro de la carpeta del proyecto:

- `work/insumos/paso_03/`, incluidas sus subcarpetas.
- `outputs/resultados_indicadores_nacionales/`, incluidas sus subcarpetas.

Si no encuentra el archivo, guarda un diagnostico y se detiene. Si encuentra varias versiones, guarda su inventario con rutas, tamanos y MD5, y exige seleccionar una explicitamente; no elige por fecha. Si se copia un CSV, conviene mantener los archivos auxiliares de su misma ejecucion en la misma carpeta.

Valida el esquema exacto del paso 03, 16 anios unicos 2010–2025, AMJ, numericos finitos, conteos enteros, denominadores e identidades de poblaciones. Recalcula las tres tasas desde los totales expandidos y comprueba coherencia con lo importado. No vuelve a ponderar las poblaciones.

Cuando existen, revisa `controles_por_anio.csv`, `metadatos_utilizados.csv` y `contraste_INE_2020_2025.csv` de la misma carpeta. Si faltan, registra la limitacion; no los declara aprobados. Las versiones de microdatos y los metadatos no se acreditan solo por el nombre del archivo ni por sus hashes.

## Como ejecutarlo en RStudio

1. Conserve la estructura de carpetas al extraer el ZIP en su computador.
2. Copie el CSV real del paso 03 y sus auxiliares a `work/insumos/paso_03/`. No necesita volver a ejecutar 01–05 si esos productos existen.
3. Abra una sesion nueva de RStudio, abra `outputs/06_01_preparar_base_laboral_AMJ.R` y pulse **Source** para ejecutar el archivo completo. No seleccione solo lineas aisladas.

El bloque de configuracion esta al inicio del script. Al ejecutarse, verifica y registra las rutas absolutas de esa copia. No supone que Documentos este en OneDrive. No se necesita instalar paquetes adicionales para este bloque.

Para usar otra ubicacion o resolver varias versiones, puede definir `ENE_PROYECTO` y/o `ENE_CSV_PASO03` con rutas absolutas existentes antes de pulsar Source. Son opciones; la copia organizada no las necesita cuando la estructura se conserva y hay un solo CSV. No introducir contrasenas ni credenciales en estas variables.

En esta nube, el comando es:

```sh
/workspace/.tools/bin/Rscript --vanilla /workspace/Andr-s-Ignacio-Barreda-Bustamante/outputs/06_01_preparar_base_laboral_AMJ.R
```

R base 4.5.0 fue preparado localmente en `/workspace/.tools/ene-r`; los lanzadores estan en `/workspace/.tools/bin`. El instalador `work/configuracion/instalar_R_nube.sh` es exclusivamente para la nube Debian amd64. No ejecutarlo en Windows: alli se usa la instalacion habitual de R/RStudio. No se instalaron los paquetes de las etapas anteriores porque no se van a repetir.

## Resultados que debe esperar

Cada ejecucion crea una carpeta propia: no sobrescribe productos anteriores.

- Siempre que alcanza la configuracion de salida: rutas, inventario de candidatos, registro de validaciones, sesion R y LEEME del estado.
- Si la entrada y los controles disponibles pasan: `tablas/base_laboral_AMJ_2010_2025.csv`, su copia `.rds`, `cambios_laborales_interanuales_pp.csv` y `graficos/01_referencia_laboral_AMJ.png`.
- Si falla: estado `DETENIDO_SIN_BASE_ANALITICA`, causa concreta y tablas/graficos vacios. Una detencion esperada por falta de entrada no es un resultado estadistico.

**Estado real de esta entrega:** falta el CSV nacional. La corrida real en el proyecto guardo el diagnostico y termino con codigo de salida 1, sin base ni graficos del estudio. Los controles funcionales usan entradas sinteticas solo bajo carpetas temporales: sus cifras no son resultados de Chile. Los reportes de pruebas estan separados en `00_revision_insumos/`.

## Interpretacion tecnica y sencilla

Tecnica: preparar el antecedente laboral exige separar consistencia interna de validacion de fuentes. Las poblaciones ya estan expandidas con `fact_cal`; las tasas son razones de esos totales, no promedios de tasas de grupos. Verificar identidades no reproduce la estimacion con microdatos ni la varianza del diseno muestral.

Sencilla: primero comprobamos que la tabla laboral no tenga anios repetidos, datos ausentes ni cuentas incompatibles. Luego podremos compararla con la economia. Este primer bloque por si solo no muestra por que subio o bajo el desempleo.

## Revision real de los scripts anteriores

- El paso 03 usa `ene` si ya existe en Environment; por ello hay que revisar la procedencia de sus productos. Su salida depende de `getwd()`; no se pudo localizar la carpeta real de aquella ejecucion en Windows.
- El paso 03 guarda el contraste de seis tasas de 2020/2025 aunque `compatible_redondeo` sea falso. Tener el CSV principal no demuestra que el contraste haya pasado. El 06.01 comprueba esa compatibilidad si recibe el auxiliar.
- El paso 03 verifica AMJ de origen, pero no las variables internas `ano_trimestre`/`mes_central`; el 04 si las comprueba. Este CSV agregado no permite repetir ese control interno.
- El CSV03 no contiene EE ni IC. Los pasos 04/05 implementan diseno muestral y documentan la convencion `certainty` para estratos con una UPM; no se validaron aqui sus resultados. No trasladar sus propiedades de precision a datos no inspeccionados.
- El 05 separa tres bloques sectoriales y analiza sexo y edad por separado; no incluye un cruce simultaneo sexo por edad. Su cierre coincide con el alcance solicitado para 06 y 07. No se encontro otro plan original en los adjuntos.
- Se conserva la organizacion por ejecucion de 04/05 y su paleta azul/verde/magenta en el grafico laboral previsto. No se inspeccionaron graficos originales, pues no fueron adjuntados.

## Macroeconomia y alcance pendiente

`00_revision_insumos/plan_alineacion_AMJ_PENDIENTE_VERIFICAR.csv` es una propuesta metodologica, no una base con observaciones ni un catalogo de series verificadas.

- PIB y FBKF: proponer volumen trimestral oficial del BCCh, T2 abril–junio, con variacion respecto de T2 del anio anterior. Verificar unidad, base/referencia, ajuste estacional y revisiones antes de decidir la serie.
- IPC: proponer promedio de las variaciones interanuales de abril, mayo y junio del INE. No equivale al IPC de junio, a inflacion acumulada anual ni necesariamente a la variacion del promedio trimestral del indice.
- Para obtener variaciones de 2010 se necesitan antecedentes 2009. Eso no amplia las 16 observaciones principales.
- No se consultaron fuentes macroeconomicas ni se inventaron cifras, codigos o enlaces de descarga. Falta verificar las series antes de unirlas.
- No se ajustaron regresiones. El paso07 se incorpora posteriormente en la entrega conjunta como revision documental y estrategia, con fuentes pendientes. El bajo crecimiento sigue siendo una hipotesis, no una conclusion.

**Proximo insumo concreto:** adjuntar `indicadores_nacionales_AMJ_2010_2025.csv`; idealmente tambien los tres auxiliares, el informe nacional y la sesion R de la misma ejecucion. Para revisar coherencia visual y precision de 04/05 posteriormente, aportar sus LEEME/informes, `tablas_04.rds`, `tablas_05.rds` y graficos disponibles.

## Configuracion de la nube guardada

Se guardaron `install_script` (instalador local de R probado desde cero y al reutilizarlo) y `start_skill` (uso de R y entradas pendientes) en el borrador del entorno. Para conservar la configuracion publicada, revise y guarde los cambios en ajustes del entorno y despues publique. No se ha comprobado restauracion en una tarea nueva.
