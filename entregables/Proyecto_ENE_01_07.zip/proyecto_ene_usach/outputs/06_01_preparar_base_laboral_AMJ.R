# 06.01 — Preparar y validar el antecedente laboral para contexto macroeconomico.
# Ejecutar TODO con Source en RStudio, en una sesion nueva. Solo requiere R base.
# No ejecuta 01–05, no usa objetos ene, no descarga datos y no estima modelos.
# Las copias de 01–05 estan en outputs/, sin modificaciones.
local({
  # 1. CONFIGURACION DE RUTAS ------------------------------------------------
  # Source identifica este archivo; Rscript usa --file. No depende de getwd().
  # Opcion: ENE_PROYECTO = ruta ABSOLUTA de la carpeta que contiene outputs/.
  # Opcion: ENE_CSV_PASO03 = ruta ABSOLUTA de un CSV concreto del paso 03.
  # No se supone ninguna ubicacion de Documentos/OneDrive en Windows.
  absoluta <- function(x) grepl("^(/|[A-Za-z]:[/\\\\]|\\\\\\\\)", x)
  raiz_configurada <- Sys.getenv("ENE_PROYECTO", unset = "")
  csv_configurado <- Sys.getenv("ENE_CSV_PASO03", unset = "")
  if (nzchar(raiz_configurada)) {
    if (!absoluta(raiz_configurada) || !dir.exists(raiz_configurada))
      stop("ENE_PROYECTO debe ser una carpeta absoluta existente.", call. = FALSE)
    raiz <- normalizePath(raiz_configurada, winslash = "/", mustWork = TRUE)
  } else {
    ofiles <- lapply(sys.frames(), function(f) f$ofile)
    ofiles <- Filter(function(x) is.character(x) && length(x) == 1L, ofiles)
    cli <- grep("^--file=", commandArgs(), value = TRUE)
    archivo <- if (length(ofiles)) tail(ofiles, 1L)[[1L]] else
      if (length(cli) == 1L) sub("^--file=", "", cli) else ""
    if (!nzchar(archivo) || !file.exists(archivo))
      stop("Ejecute el archivo completo con Source o Rscript; alternativamente defina ENE_PROYECTO.", call. = FALSE)
    raiz <- dirname(dirname(normalizePath(archivo, winslash = "/", mustWork = TRUE)))
  }
  originales <- c("01_inventario_ene.R", "02_diagnostico_y_union_ene.R",
    "03_indicadores_laborales_nacionales.R", "04_indicadores_laborales_sexo_edad.R",
    "05_empleo_sectores_productivos.R")
  if (!all(file.exists(file.path(raiz, "outputs", originales))))
    stop("La raiz no contiene las cinco copias originales en outputs/. Revise ENE_PROYECTO.", call. = FALSE)
  carpetas_busqueda <- file.path(raiz, c("work/insumos/paso_03",
    "outputs/resultados_indicadores_nacionales"))
  salida_raiz <- file.path(raiz, "outputs", "resultados_06_contexto_macroeconomico", "ejecuciones")
  for (p in c(carpetas_busqueda, file.path(raiz, "work", "insumos", "macroeconomia"), salida_raiz)) {
    if (!dir.exists(p) && !dir.create(p, recursive = TRUE)) stop("No se pudo crear: ", p)
  }
  salida <- tempfile(paste0("06_01_", format(Sys.time(), "%Y%m%d_%H%M%S"), "_"), tmpdir = salida_raiz)
  if (!dir.create(salida)) stop("No se pudo crear una carpeta nueva de ejecucion.")
  for (p in c("tablas", "graficos", "controles", "documentacion"))
    if (!dir.create(file.path(salida, p))) stop("No se pudo crear subcarpeta: ", p)

  ejecutar <- function() {
    registro <- data.frame(control = character(), estado = character(), detalle = character())
    pendientes <- character()
    csv_origen <- "No seleccionado"
    guardar <- function(x, carpeta, nombre) write.csv(x, file.path(salida, carpeta, nombre),
      row.names = FALSE, na = "", fileEncoding = "UTF-8")
    anotar <- function(nombre, estado, detalle = "") {
      registro <<- rbind(registro, data.frame(control = nombre, estado = estado, detalle = detalle))
    }
    comprobar <- function(condicion, nombre, detalle = "") {
      ok <- isTRUE(condicion)
      anotar(nombre, if (ok) "PASA" else "FALLA", detalle)
      if (!ok) stop(nombre, if (nzchar(detalle)) paste0(": ", detalle), call. = FALSE)
    }
    pendiente <- function(nombre) {
      pendientes <<- c(pendientes, nombre)
      anotar(nombre, "PENDIENTE", "No disponible: no se considera verificado.")
    }
    leer <- function(f) {
      x <- read.csv(f, stringsAsFactors = FALSE, check.names = FALSE,
        fileEncoding = "UTF-8-BOM", na.strings = c("", "NA"))
      comprobar(!anyDuplicated(names(x)), paste0("Columnas unicas: ", basename(f)))
      x
    }
    requerir <- function(x, columnas, nombre) comprobar(all(columnas %in% names(x)),
      paste0("Esquema: ", nombre), paste(setdiff(columnas, names(x)), collapse = ", "))
    anios_validos <- function(x) nrow(x) == 16L && is.numeric(x$anio) &&
      !anyNA(x$anio) && !anyDuplicated(x$anio) && setequal(x$anio, 2010:2025)
    cerrar <- function(estado, detalle) {
      guardar(registro, "controles", "validaciones_06_01.csv")
      capture.output(sessionInfo(), file = file.path(salida, "documentacion", "sesion_R_06_01.txt"))
      texto <- c("# 06.01 — Preparacion del antecedente laboral", "",
        paste0("Estado: **", estado, "**"), detalle, "",
        paste0("Raiz verificada: `", raiz, "`"),
        paste0("CSV de origen: `", csv_origen, "`"),
        paste0("Salida nueva: `", normalizePath(salida, winslash = "/"), "`"), "",
        "## Interpretacion tecnica",
        "Se verifican estructura, cobertura e identidades de estimaciones agregadas del paso 03. No se vuelven a expandir sus poblaciones: ya estan ponderadas. Una identidad contable correcta no valida por si sola la muestra, los filtros ni la comparabilidad conceptual.",
        "## Lectura sencilla",
        "Este bloque comprueba que la tabla laboral encaje consigo misma antes de relacionarla con la economia. Si falta la tabla o falla un control, no se crea una base analitica nueva.",
        "## Limites y siguiente bloque",
        "AMJ de cada anio, 2010–2025: 16 cortes; no promedios anuales ni seguimiento de personas. No se estiman errores estandar, intervalos, significancia ni efectos causales. El CSV03 no contiene el diseno muestral. 2026 queda fuera.",
        "El contraste importado de 2020 y 2025, si existe, solo se revisa como antecedente provisto: no equivale a consultar ahora las publicaciones del INE. El script03 lo exporta incluso cuando no coincide con redondeo.",
        "La base laboral preparada NO incluye macroeconomia. Antes de unir PIB, FBKF e IPC, verificar fuentes oficiales, unidades, revisiones, frecuencia, transformaciones y fecha de consulta. No se han verificado codigos de series ni enlaces de descarga.",
        "La propuesta es PIB y FBKF reales en T2 con variacion interanual; IPC con promedio de las tres variaciones interanuales mensuales de abril, mayo y junio. Requiere antecedentes de 2009 para obtener variaciones de 2010. No ampliar el periodo principal sin justificacion.", "",
        "## Antecedentes faltantes", if (length(pendientes)) paste0("- ", pendientes) else
          "Consulte validaciones_06_01.csv: no tener pendientes listados no implica que todos los controles hayan llegado a ejecutarse.")
      writeLines(enc2utf8(texto), file.path(salida, "documentacion", "LEEME_06_01.md"), useBytes = TRUE)
      message("Estado: ", estado, "\nResultados de esta ejecucion: ", normalizePath(salida, winslash = "/"))
    }

    tryCatch({
      # 2. LOCALIZAR ENTRADA SIN ELEGIR AUTOMATICAMENTE ENTRE VERSIONES --------
      guardar(data.frame(tipo = c("raiz", "busqueda_1", "busqueda_2", "CSV_explicito"),
        ruta = c(raiz, carpetas_busqueda, csv_configurado)), "controles", "rutas_configuradas.csv")
      candidatos <- as.character(unlist(lapply(carpetas_busqueda, function(p)
        list.files(p, pattern = "^indicadores_nacionales_AMJ_2010_2025[.]csv$",
          recursive = TRUE, full.names = TRUE)), use.names = FALSE))
      if (length(candidatos)) candidatos <- unique(normalizePath(candidatos, winslash = "/", mustWork = TRUE))
      if (nzchar(csv_configurado)) {
        comprobar(absoluta(csv_configurado) && file.exists(csv_configurado), "Ruta explicita CSV valida")
        csv_origen <- normalizePath(csv_configurado, winslash = "/", mustWork = TRUE)
        candidatos <- unique(c(candidatos, csv_origen))
      }
      inventario <- data.frame(ruta = candidatos, bytes = as.numeric(file.info(candidatos)$size),
        md5 = unname(tools::md5sum(candidatos)), stringsAsFactors = FALSE)
      guardar(inventario, "controles", "candidatos_csv_paso03.csv")
      if (!nzchar(csv_configurado)) {
        comprobar(length(candidatos) == 1L, "Un CSV nacional identificado",
          if (!length(candidatos)) paste0("Falta indicadores_nacionales_AMJ_2010_2025.csv. Buscado en: ",
            paste(carpetas_busqueda, collapse = " | ")) else
            "Hay varias versiones. Revise candidatos_csv_paso03.csv y defina ENE_CSV_PASO03; no se elige la mas reciente.")
        csv_origen <- candidatos[1L]
      }
      adyacentes <- file.path(dirname(csv_origen), c("controles_por_anio.csv", "metadatos_utilizados.csv",
        "contraste_INE_2020_2025.csv", "informe_nacional.md", "sesion_R.txt"))
      guardar(data.frame(ruta = adyacentes, disponible = file.exists(adyacentes),
        md5 = unname(tools::md5sum(adyacentes))), "controles", "antecedentes_disponibles.csv")

      # 3. VALIDAR TABLA NACIONAL DEL PASO 03 ---------------------------------
      x <- leer(csv_origen)
      ncols <- c("n_muestra_pet", "n_muestra_ocupados", "n_muestra_desocupados", "n_muestra_fuera_ft")
      pcols <- c("pet_personas", "ocupados_personas", "desocupados_personas", "fuera_ft_personas", "fuerza_trabajo_personas")
      tasas <- c("tasa_participacion", "tasa_ocupacion", "tasa_desocupacion")
      requerir(x, c("anio", "trimestre", ncols, pcols, tasas), "CSV nacional")
      comprobar(anios_validos(x), "Exactamente 16 anios unicos 2010–2025; sin 2026")
      comprobar(!anyNA(x$trimestre) && all(toupper(trimws(x$trimestre)) == "AMJ"), "Solo AMJ")
      comprobar(all(vapply(x[c(ncols, pcols, tasas)], is.numeric, logical(1))), "Columnas cuantitativas numericas")
      comprobar(all(is.finite(as.matrix(x[c(ncols, pcols, tasas)]))), "Sin faltantes ni valores no finitos")
      comprobar(all(as.matrix(x[c(ncols, pcols)]) >= 0), "Poblaciones y muestras no negativas")
      comprobar(all(as.matrix(x[ncols]) == floor(as.matrix(x[ncols]))), "Conteos muestrales enteros")
      comprobar(all(x$pet_personas > 0 & x$fuerza_trabajo_personas > 0 & x$n_muestra_pet > 0 &
        x$n_muestra_ocupados + x$n_muestra_desocupados > 0), "Denominadores positivos")
      comprobar(all(x$n_muestra_pet == x$n_muestra_ocupados + x$n_muestra_desocupados + x$n_muestra_fuera_ft),
        "Reconciliacion de conteos muestrales")
      comprobar(all(abs(x$fuerza_trabajo_personas - x$ocupados_personas - x$desocupados_personas) < 0.01) &&
        all(abs(x$pet_personas - x$fuerza_trabajo_personas - x$fuera_ft_personas) < 0.01),
        "Reconciliacion poblacional", "Tolerancia: menos de 0,01 persona por identidad.")
      comprobar(all(as.matrix(x[tasas]) >= 0 & as.matrix(x[tasas]) <= 100), "Tasas entre 0 y 100")
      razones <- cbind(100 * x$fuerza_trabajo_personas / x$pet_personas,
        100 * x$ocupados_personas / x$pet_personas, 100 * x$desocupados_personas / x$fuerza_trabajo_personas)
      comprobar(max(abs(as.matrix(x[tasas]) - razones)) < 1e-6, "Tasas coinciden con razones de totales",
        "Tolerancia: menos de 0,000001 puntos porcentuales.")
      x <- x[order(x$anio), c("anio", "trimestre", ncols, pcols, tasas)]
      x$trimestre <- "AMJ"

      # 4. REVISAR CONTROLES DE LA MISMA CARPETA, SI ESTAN DISPONIBLES ----------
      if (file.exists(adyacentes[1L])) {
        c03 <- leer(adyacentes[1L])
        problemas <- c("n_edad_faltante", "n_edad_invalida_no_faltante", "n_pet_activ_faltante",
          "n_pet_activ_invalida", "n_pet_peso_faltante", "n_pet_peso_invalido", "n_pet_cae_invalido",
          "n_pet_discrepancia_activ_cae", "n_pet_no_utilizables")
        requerir(c03, c("anio", "n_total", "n_pet", "n_menores_15", problemas), "controles 03")
        comprobar(anios_validos(c03), "Cobertura controles 03")
        comprobar(all(vapply(c03[c("n_total", "n_pet", "n_menores_15", problemas)], is.numeric, logical(1))) &&
          all(is.finite(as.matrix(c03[c("n_total", "n_pet", "n_menores_15", problemas)]))), "Controles 03 numericos finitos")
        conteos <- as.matrix(c03[c("n_total", "n_pet", "n_menores_15", problemas)])
        comprobar(all(conteos >= 0 & conteos == floor(conteos)), "Controles 03 enteros no negativos")
        comprobar(all(as.matrix(c03[problemas]) == 0), "Controles 03 sin incidencias")
        c03 <- c03[match(x$anio, c03$anio), ]
        comprobar(all(c03$n_pet == x$n_muestra_pet) && all(c03$n_total == c03$n_pet + c03$n_menores_15),
          "Controles 03 reconciliados con CSV")
      } else pendiente("controles_por_anio.csv")
      if (file.exists(adyacentes[2L])) {
        meta <- leer(adyacentes[2L])
        requerir(meta, c("anio", "variable", "etiqueta_variable", "etiquetas_valores"), "metadatos 03")
        esperados <- expand.grid(anio = 2010:2025, variable = c("edad", "activ", "cae_especifico", "fact_cal"))
        comprobar(nrow(meta) == 64L && !anyDuplicated(meta[c("anio", "variable")]) &&
          setequal(paste(meta$anio, meta$variable), paste(esperados$anio, esperados$variable)), "Cobertura metadatos 03")
        for (v in c("activ", "cae_especifico", "fact_cal")) {
          m <- meta[meta$variable == v, ]
          comprobar(!anyNA(m[c("etiqueta_variable", "etiquetas_valores")]) &&
            length(unique(m$etiqueta_variable)) == 1L && length(unique(m$etiquetas_valores)) == 1L,
            paste0("Etiquetas constantes en metadatos: ", v))
        }
        comprobar(all(grepl("2017", meta$etiqueta_variable[meta$variable == "fact_cal"], fixed = TRUE)),
          "Etiqueta de fact_cal refiere a 2017", "No reemplaza revisar atributos originales ni documentacion INE.")
      } else pendiente("metadatos_utilizados.csv")
      if (file.exists(adyacentes[3L])) {
        contraste <- leer(adyacentes[3L])
        requerir(contraste, c("anio", "indicador", "tasa_publicada", "tasa_calculada", "compatible_redondeo"), "contraste provisto")
        esperado <- expand.grid(anio = c(2020, 2025), indicador = tasas)
        comprobar(nrow(contraste) == 6L && !anyDuplicated(contraste[c("anio", "indicador")]) &&
          setequal(paste(contraste$anio, contraste$indicador), paste(esperado$anio, esperado$indicador)),
          "Cobertura de seis tasas en contraste provisto")
        comprobar(is.numeric(contraste$tasa_publicada) && is.numeric(contraste$tasa_calculada) &&
          all(is.finite(contraste$tasa_publicada)) && all(is.finite(contraste$tasa_calculada)), "Tasas del contraste finitas")
        calculadas <- mapply(function(y, v) x[x$anio == y, v], contraste$anio, contraste$indicador)
        comprobar(all(abs(calculadas - contraste$tasa_calculada) < 1e-6), "Contraste corresponde a tasas importadas")
        comprobar(all(abs(calculadas - contraste$tasa_publicada) <= 0.0500001) &&
          is.logical(contraste$compatible_redondeo) && all(contraste$compatible_redondeo %in% TRUE),
          "Contraste provisto compatible con redondeo", "Verificacion interna; fuentes oficiales no reconsultadas.")
      } else pendiente("contraste_INE_2020_2025.csv")

      # 5. SALIDAS LABORALES; TODAVIA SIN UNION CON MACROECONOMIA --------------
      x$fecha_inicio_AMJ <- sprintf("%d-04-01", x$anio)
      x$fecha_fin_AMJ <- sprintf("%d-06-30", x$anio)
      x$trimestre_calendario <- "T2"
      guardar(x, "tablas", "base_laboral_AMJ_2010_2025.csv")
      saveRDS(x, file.path(salida, "tablas", "base_laboral_AMJ_2010_2025.rds"))
      cambios <- x[c("anio", "trimestre")]
      for (v in tasas) cambios[[paste0(v, "_cambio_pp")]] <- c(NA_real_, diff(x[[v]]))
      guardar(cambios, "tablas", "cambios_laborales_interanuales_pp.csv")
      gr <- file.path(salida, "graficos", "01_referencia_laboral_AMJ.png")
      png(gr, width = 2100, height = 1000, res = 180)
      dispositivo <- dev.cur()
      tryCatch({
        par(mfrow = c(1, 3), mar = c(4, 4.5, 3, 1), oma = c(4, 0, 2, 0), las = 1,
          bg = "white", col.axis = "#334155", col.lab = "#334155")
        for (j in seq_along(tasas)) {
          plot(x$anio, x[[tasas[j]]], type = "n", xlab = "Ano (AMJ)", ylab = "Porcentaje (%)",
            ylim = c(0, if (j == 3L) max(20, ceiling(max(x[[tasas[j]]]) / 5) * 5) else 100),
            main = c("Participacion", "Ocupacion", "Desocupacion")[j], xaxt = "n")
          axis(1, at = c(2010, 2013, 2016, 2019, 2022, 2025))
          grid(nx = NA, ny = NULL, col = "#E3E6EA")
          abline(v = 2020, lty = 3, col = "#AAAAAA")
          lines(x$anio, x[[tasas[j]]], type = "o", pch = 16, lwd = 2,
            col = c("#215B86", "#147D92", "#A14470")[j])
        }
        mtext("Chile | Referencia laboral para paso 06 | AMJ 2010–2025", outer = TRUE, side = 3, font = 2)
        mtext("Fuente: CSV del paso 03, elaborado con microdatos ENE, INE y fact_cal. No promedios anuales.",
          outer = TRUE, side = 1, line = 1, cex = 0.7)
        mtext("Sin IC ni pruebas de cambios. Linea vertical: 2020. Macroeconomia pendiente de incorporar.",
          outer = TRUE, side = 1, line = 2.4, cex = 0.7)
      }, finally = dev.off(dispositivo))
      cerrar(if (length(pendientes)) "CONSISTENCIA_INTERNA_OK_CON_ANTECEDENTES_PENDIENTES" else
        "CONSISTENCIA_INTERNA_Y_ANTECEDENTES_OK",
        "Base laboral preparada desde el CSV existente. Paso 06 completo pendiente: faltan series macroeconomicas verificadas.")
      invisible(salida)
    }, error = function(e) {
      # Si una exportacion falla, tampoco quedan productos parciales como validos.
      unlink(list.files(file.path(salida, "tablas"), full.names = TRUE))
      unlink(list.files(file.path(salida, "graficos"), full.names = TRUE))
      anotar("Ejecucion", "DETENIDA", conditionMessage(e))
      cerrar("DETENIDO_SIN_BASE_ANALITICA", conditionMessage(e))
      stop(conditionMessage(e), call. = FALSE)
    })
  }
  ejecutar()
})
