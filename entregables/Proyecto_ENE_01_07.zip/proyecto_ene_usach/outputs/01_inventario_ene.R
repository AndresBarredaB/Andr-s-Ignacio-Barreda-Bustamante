# Inventario ENE: solo lectura de originales, sin unir observaciones ni calcular tasas.
# Rscript 01_inventario_ene.R "ruta/bases" "ruta/resultados"
args <- commandArgs(trailingOnly = TRUE)
carpeta_bases <- if (length(args) >= 1L) args[1] else
  "C:/Users/andre/OneDrive/Escritorio/USACH-ING COMERCIAL/4 SEMESTRE/POLITICA ECONOMICA/BASES DE DATOS 2010-2026"
carpeta_resultados <- if (length(args) >= 2L) args[2] else file.path(getwd(), "resultados_ene")
if (!requireNamespace("haven", quietly = TRUE))
  stop('Falta haven. Ejecute install.packages("haven") y vuelva a ejecutar el script.')
if (!dir.exists(carpeta_bases)) stop("No existe o no es accesible la carpeta de bases: ", carpeta_bases)
archivos <- sort(list.files(carpeta_bases, pattern = "\\.dta$", full.names = TRUE,
                            recursive = TRUE, ignore.case = TRUE))
if (!length(archivos)) stop("No se encontraron archivos .dta; no se generaron resultados.")
dir.create(carpeta_resultados, recursive = TRUE, showWarnings = FALSE)
requeridas <- c("edad", "sexo", "activ", "cae_especifico", "fact_cal")
inventarios <- list()
esquemas <- list()
extraer <- function(nombre, patron) {
  m <- regexec(patron, tolower(nombre), perl = TRUE)
  r <- regmatches(tolower(nombre), m)[[1]]
  if (length(r) >= 2L) r[2] else NA_character_
}
for (i in seq_along(archivos)) {
  f <- archivos[i]
  nombre <- basename(f)
  anio <- as.integer(extraer(nombre, "(?:^|[^0-9])((?:19|20)[0-9]{2})(?:[^0-9]|$)"))
  trimestre <- extraer(nombre, "-([a-z]{3})(?:[ .(]|$)")
  periodo <- if (is.na(anio)) "sin_anio" else if (anio >= 2010 && anio <= 2025)
    "principal_2010_2025" else if (anio == 2026) "separado_2026" else "fuera_periodo"
  avisos <- character()
  error <- ""
  message("Leyendo ", i, "/", length(archivos), ": ", nombre)
  datos <- tryCatch(withCallingHandlers(haven::read_dta(f, .name_repair = "minimal"),
    warning = function(w) { avisos <<- c(avisos, conditionMessage(w)); invokeRestart("muffleWarning") }),
    error = function(e) { error <<- conditionMessage(e); NULL })
  fila <- data.frame(archivo = nombre, ruta = normalizePath(f, winslash = "/"),
    anio = anio, trimestre_nombre = trimestre, periodo = periodo,
    filas = if (is.null(datos)) NA_integer_ else nrow(datos),
    columnas = if (is.null(datos)) NA_integer_ else ncol(datos),
    estado = if (is.null(datos)) "error" else "leido",
    error = error, advertencias = paste(unique(avisos), collapse = " | "),
    nombres_duplicados = if (is.null(datos)) NA else anyDuplicated(names(datos)) > 0L,
    stringsAsFactors = FALSE)
  for (v in requeridas) fila[[paste0("existe_", v)]] <-
    if (is.null(datos)) NA else v %in% names(datos)
  inventarios[[i]] <- fila
  if (!is.null(datos)) {
    esquemas[[length(esquemas) + 1L]] <- data.frame(
      archivo = nombre, ruta = fila$ruta, anio = anio,
      trimestre_nombre = trimestre, periodo = periodo, variable = names(datos),
      tipo_R = vapply(datos, typeof, character(1)),
      clase_R = vapply(datos, function(x) paste(class(x), collapse = ";"), character(1)),
      formato_Stata = vapply(datos, function(x) {
        z <- attr(x, "format.stata"); if (is.null(z)) "" else paste(z, collapse = ";")
      }, character(1)), stringsAsFactors = FALSE)
  }
  rm(datos)
  invisible(gc())
}
inventario <- do.call(rbind, inventarios)
esquema <- if (length(esquemas)) do.call(rbind, esquemas) else data.frame(
  archivo = character(), ruta = character(), anio = integer(),
  trimestre_nombre = character(), periodo = character(), variable = character(),
  tipo_R = character(), clase_R = character(), formato_Stata = character())
guardar <- function(x, nombre) write.csv(x, file.path(carpeta_resultados, nombre),
                                        row.names = FALSE, na = "", fileEncoding = "UTF-8")
guardar(inventario, "inventario_todos.csv")
guardar(inventario[inventario$periodo == "principal_2010_2025", ], "inventario_2010_2025.csv")
guardar(inventario[inventario$periodo == "separado_2026", ], "inventario_2026.csv")
guardar(esquema, "diccionario_variables.csv")
# Todas las parejas de archivos de distinto año dentro de cada período y trimestre.
# Se comparan solo metadatos; nunca se concatenan las observaciones de las bases.
comparaciones <- list()
for (p in unique(esquema$periodo)) {
  for (t in unique(esquema$trimestre_nombre[esquema$periodo == p])) {
    if (is.na(t)) next
    s <- esquema[esquema$periodo == p & !is.na(esquema$trimestre_nombre) &
                   esquema$trimestre_nombre == t, ]
    rutas <- unique(s$ruta)
    if (length(rutas) < 2L) next
    pares <- combn(rutas, 2L, simplify = FALSE)
    for (par in pares) {
      a <- s[s$ruta == par[1], ]; b <- s[s$ruta == par[2], ]
      if (is.na(a$anio[1]) || is.na(b$anio[1]) || a$anio[1] == b$anio[1]) next
      variables <- union(a$variable, b$variable)
      ia <- match(variables, a$variable); ib <- match(variables, b$variable)
      estado <- ifelse(is.na(ia), "solo_en_b", ifelse(is.na(ib), "solo_en_a",
        ifelse(a$tipo_R[ia] != b$tipo_R[ib] | a$clase_R[ia] != b$clase_R[ib],
               "tipo_o_clase_diferente", "igual")))
      comparaciones[[length(comparaciones) + 1L]] <- data.frame(
        periodo = p, trimestre_nombre = t, archivo_a = a$archivo[1],
        anio_a = a$anio[1], archivo_b = b$archivo[1], anio_b = b$anio[1],
        variable = variables, tipo_a = a$tipo_R[ia], clase_a = a$clase_R[ia],
        tipo_b = b$tipo_R[ib], clase_b = b$clase_R[ib], resultado = estado)
    }
  }
}
comparacion <- if (length(comparaciones)) do.call(rbind, comparaciones) else data.frame(
  periodo = character(), trimestre_nombre = character(), archivo_a = character(),
  anio_a = integer(), archivo_b = character(), anio_b = integer(), variable = character(),
  tipo_a = character(), clase_a = character(), tipo_b = character(), clase_b = character(),
  resultado = character())
guardar(comparacion, "comparacion_entre_anios.csv")
guardar(comparacion[comparacion$resultado != "igual", ], "diferencias_entre_anios.csv")
cobertura <- data.frame(anio = 2010:2026)
cobertura$periodo <- ifelse(cobertura$anio == 2026, "separado_2026", "principal_2010_2025")
cobertura$archivos_detectados <- vapply(cobertura$anio,
  function(y) sum(inventario$anio == y, na.rm = TRUE), integer(1))
cobertura$archivos_leidos <- vapply(cobertura$anio,
  function(y) sum(inventario$anio == y & inventario$estado == "leido", na.rm = TRUE), integer(1))
guardar(cobertura, "cobertura_anios.csv")
capture.output(sessionInfo(), file = file.path(carpeta_resultados, "sesion_R.txt"))
message("Inventario finalizado. Resultados: ", normalizePath(carpeta_resultados, winslash = "/"))
