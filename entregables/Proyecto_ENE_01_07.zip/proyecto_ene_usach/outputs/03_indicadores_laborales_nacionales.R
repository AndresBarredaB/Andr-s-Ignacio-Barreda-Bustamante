# 1. OBJETIVO Y RUTAS --------------------------------------------------------
# Analisis nacional ENE, abril-junio (AMJ), 2010-2025.
# Abrir en RStudio y pulsar Source. Usa R base: no necesita instalar paquetes.
# Si ene ya existe en RStudio, se reutiliza sin modificarlo.
carpeta_union <- "C:/Users/andre/OneDrive/Documentos/resultados_union_ene/20261026_222723_68fc296a7de5"
archivo_union <- file.path(carpeta_union, "ene_2010_2025_union_tecnica.rds")
# Puede cambiar esta ruta para guardar los resultados donde prefiera.
carpeta_salida <- file.path(getwd(), "resultados_indicadores_nacionales")
dir.create(carpeta_salida, recursive = TRUE, showWarnings = FALSE)
guardar_csv <- function(x, nombre) write.csv(x, file.path(carpeta_salida, nombre),
  row.names = FALSE, fileEncoding = "UTF-8", na = "")

# 2. CARGAR LA BASE UNIFICADA O REUTILIZAR ene --------------------------------
if (!exists("ene", inherits = FALSE)) {
  if (!file.exists(archivo_union)) stop("No se encuentra la base unificada.")
  message("Leyendo la base unificada. Puede tardar y requiere varios GB de RAM.")
  ene <- readRDS(archivo_union)
}
requeridas <- c("edad", "activ", "cae_especifico", "fact_cal",
  "ene_anio_origen", "ene_trimestre_origen", "ene_archivo_origen", "ene_fila_origen")
if (!all(requeridas %in% names(ene)))
  stop("Faltan columnas: ", paste(setdiff(requeridas, names(ene)), collapse = ", "))
# Una tabla pequena evita copiar las 275 columnas al trabajar.
d <- as.data.frame(ene[requeridas])
if (anyNA(d$ene_anio_origen)) stop("Hay observaciones sin anio de origen.")
d <- d[d$ene_anio_origen %in% 2010:2025, ]
if (!setequal(unique(d$ene_anio_origen), 2010:2025)) stop("Faltan anios de 2010-2025.")
if (anyNA(d$ene_trimestre_origen) || any(tolower(d$ene_trimestre_origen) != "amj"))
  stop("Este script requiere exclusivamente AMJ.")
if (anyDuplicated(d[c("ene_archivo_origen", "ene_fila_origen")]))
  stop("Se repiten filas de origen; revise la union.")
if (!all(vapply(d[c("edad", "activ", "cae_especifico", "fact_cal")], is.numeric, logical(1))))
  stop("Las variables centrales deben ser numericas.")

# 3. CONFIRMAR CODIGOS Y FACTOR CON LOS METADATOS EXISTENTES -------------------
dic <- read.csv(file.path(carpeta_union, "diccionario_por_anio.csv"),
                fileEncoding = "UTF-8", stringsAsFactors = FALSE)
meta <- dic[dic$anio %in% 2010:2025 & dic$variable %in%
              c("edad", "activ", "cae_especifico", "fact_cal"), ]
if (nrow(meta) != 64L || any(table(meta$anio, meta$variable) != 1L))
  stop("Metadatos incompletos o duplicados para las variables centrales.")
for (v in c("activ", "cae_especifico", "fact_cal")) {
  z <- meta[meta$variable == v, ]
  if (length(unique(z$etiquetas_valores)) != 1L ||
      length(unique(z$etiqueta_variable)) != 1L) stop("Revisar metadatos cambiantes: ", v)
}
# Atributos originales: verificar los codigos, no evaluar texto como codigo R.
atributos <- readRDS(file.path(carpeta_union, "atributos_originales_por_archivo.rds"))
for (f in unique(d$ene_archivo_origen)) {
  k <- which(basename(names(atributos)) == f)
  if (length(k) != 1L) stop("No se identificaron atributos para ", f)
  labs <- atributos[[k]]$activ$labels
  if (!identical(as.numeric(labs), c(1, 2, 3)) ||
      !identical(enc2utf8(names(labs)), enc2utf8(c("Ocupados/as", "Desocupados/as", "Fuera de la fuerza de trabajo"))))
    stop("Codificacion activ distinta de la verificada en ", f)
  if (!grepl("2017", atributos[[k]]$fact_cal$label, fixed = TRUE))
    stop("Revisar version del factor de expansion en ", f)
}
guardar_csv(meta, "metadatos_utilizados.csv")
# PET: edad >= 15; activ: 1 ocupado, 2 desocupado, 3 fuera de FT.
# fact_cal: factor trimestral calibrado, proyecciones Censo 2017.
# Se conserva la clasificacion oficial, incluyendo ocupados ausentes.

# 4. CONTROLAR EDAD, CONDICION LABORAL Y PONDERADORES --------------------------
d$edad_valida <- is.finite(d$edad) & d$edad >= 0 & d$edad == floor(d$edad)
d$pet <- d$edad_valida & d$edad >= 15
d$peso_valido <- is.finite(d$fact_cal) & d$fact_cal > 0
d$activ_valida <- d$activ %in% 1:3
d$activ_desde_cae <- ifelse(d$cae_especifico %in% 1:7, 1L,
  ifelse(d$cae_especifico %in% 8:9, 2L,
  ifelse(d$cae_especifico %in% 10:28, 3L, NA_integer_)))
controles <- do.call(rbind, lapply(2010:2025, function(y) {
  z <- d[d$ene_anio_origen == y, ]
  data.frame(anio = y, n_total = nrow(z),
    n_edad_faltante = sum(is.na(z$edad)),
    n_edad_invalida_no_faltante = sum(!z$edad_valida & !is.na(z$edad)),
    n_menores_15 = sum(z$edad_valida & z$edad < 15), n_pet = sum(z$pet),
    n_pet_activ_faltante = sum(z$pet & is.na(z$activ)),
    n_pet_activ_invalida = sum(z$pet & !is.na(z$activ) & !z$activ_valida),
    n_pet_peso_faltante = sum(z$pet & is.na(z$fact_cal)),
    n_pet_peso_invalido = sum(z$pet & !is.na(z$fact_cal) & !z$peso_valido),
    n_pet_cae_invalido = sum(z$pet & is.na(z$activ_desde_cae)),
    n_pet_discrepancia_activ_cae = sum(z$pet & z$activ_valida &
      !is.na(z$activ_desde_cae) & z$activ != z$activ_desde_cae, na.rm = TRUE),
    n_pet_no_utilizables = sum(z$pet & (!z$activ_valida | !z$peso_valido)))
}))
guardar_csv(controles, "controles_por_anio.csv")
problemas <- setdiff(names(controles), c("anio", "n_total", "n_menores_15", "n_pet"))
if (any(as.matrix(controles[problemas]) > 0))
  stop("Hay problemas de calidad: revise controles_por_anio.csv antes de calcular tasas. No se excluyeron silenciosamente.")

# 5. CALCULAR POBLACIONES Y TASAS PONDERADAS ----------------------------------
indicadores <- do.call(rbind, lapply(2010:2025, function(y) {
  z <- d[d$ene_anio_origen == y & d$pet, ]
  pet <- sum(z$fact_cal)
  o <- sum(z$fact_cal[z$activ == 1])
  des <- sum(z$fact_cal[z$activ == 2])
  fft <- sum(z$fact_cal[z$activ == 3])
  ft <- o + des
  if (pet <= 0 || ft <= 0) stop("Denominador no positivo en ", y)
  data.frame(anio = y, trimestre = "AMJ", n_muestra_pet = nrow(z),
    n_muestra_ocupados = sum(z$activ == 1), n_muestra_desocupados = sum(z$activ == 2),
    n_muestra_fuera_ft = sum(z$activ == 3),
    pet_personas = pet, ocupados_personas = o, desocupados_personas = des,
    fuera_ft_personas = fft, fuerza_trabajo_personas = ft,
    tasa_participacion = 100 * ft / pet,
    tasa_ocupacion = 100 * o / pet, tasa_desocupacion = 100 * des / ft)
}))
tasas <- c("tasa_participacion", "tasa_ocupacion", "tasa_desocupacion")
stopifnot(all(abs(with(indicadores, pet_personas - fuerza_trabajo_personas - fuera_ft_personas)) < 0.01),
          all(as.matrix(indicadores[tasas]) >= 0), all(as.matrix(indicadores[tasas]) <= 100))
guardar_csv(indicadores, "indicadores_nacionales_AMJ_2010_2025.csv")
print(indicadores[c("anio", "n_muestra_pet", tasas)], row.names = FALSE)

# 6. CALCULAR CAMBIOS EN PUNTOS PORCENTUALES ----------------------------------
cambios <- indicadores[c("anio", "trimestre")]
for (v in tasas) cambios[[paste0(v, "_cambio_pp")]] <- c(NA, diff(indicadores[[v]]))
guardar_csv(cambios, "variaciones_interanuales_pp.csv")
pares <- data.frame(desde = c(2010, 2019, 2019, 2019), hasta = c(2025, 2020, 2021, 2025))
comparaciones <- do.call(rbind, lapply(seq_len(nrow(pares)), function(i) {
  a <- indicadores[indicadores$anio == pares$desde[i], ]
  b <- indicadores[indicadores$anio == pares$hasta[i], ]
  data.frame(desde = a$anio, hasta = b$anio, indicador = tasas,
    tasa_inicial = as.numeric(a[1, tasas]), tasa_final = as.numeric(b[1, tasas]),
    cambio_pp = as.numeric(b[1, tasas]) - as.numeric(a[1, tasas]))
}))
guardar_csv(comparaciones, "comparaciones_periodos_pp.csv")

# 7. CONTRASTAR CON PUBLICACIONES OFICIALES DEL INE ---------------------------
# Contraste parcial: AMJ 2020 y 2025; cifras publicadas con un decimal.
# No equivale a haber cotejado todos los anios ni las versiones mas recientes.
url_2020 <- "https://www.ine.gob.cl/sala-de-prensa/prensa/general/noticia/2020/07/31/ine-publica-resultados-de-la-encuesta-nacional-de-empleo-del-trimestre-abril-junio-de-2020"
url_2025 <- "https://www.ine.gob.cl/sala-de-prensa/prensa/general/noticia/2025/07/30/la-tasa-de-desocupaci%C3%B3n-nacional-fue-8-9-en-el-trimestre-abril---junio-de-2025"
oficial <- data.frame(anio = rep(c(2020, 2025), each = 3), indicador = rep(tasas, 2),
  tasa_publicada = c(51.9, 45.6, 12.2, 61.9, 56.4, 8.9),
  fuente = rep(c(url_2020, url_2025), each = 3))
oficial$tasa_calculada <- mapply(function(y, v) indicadores[indicadores$anio == y, v],
                                oficial$anio, oficial$indicador)
oficial$diferencia_pp <- oficial$tasa_calculada - oficial$tasa_publicada
oficial$compatible_redondeo <- abs(oficial$diferencia_pp) <= 0.0500001
guardar_csv(oficial, "contraste_INE_2020_2025.csv")

# 8. CREAR TRES GRAFICOS DE EVOLUCION -----------------------------------------
titulos <- c("Participación laboral", "Ocupación", "Desocupación")
colores <- c("#185A7D", "#18756C", "#A53A38")
for (j in seq_along(tasas)) {
  png(file.path(carpeta_salida, paste0(tasas[j], ".png")), width = 1800, height = 1100, res = 180)
  par(mar = c(6, 5, 4, 1), las = 1)
  valores <- indicadores[[tasas[j]]]
  plot(indicadores$anio, valores, type = "n", xaxt = "n", xlab = "Año (abril-junio)",
    ylab = "Porcentaje (%)", ylim = c(0, ceiling(max(valores) / 10) * 10),
    main = paste0(titulos[j], " en Chile | AMJ 2010–2025"))
  grid(nx = NA, ny = NULL, col = "#E5E7EB")
  abline(v = 2020, col = "#999999", lty = 3)
  axis(1, at = 2010:2025, cex.axis = 0.75)
  lines(indicadores$anio, valores, type = "o", pch = 19, col = colores[j], lwd = 2)
  mtext("Fuente: microdatos ENE, INE. Elaboración propia con fact_cal. AMJ; no promedio anual.",
    side = 1, line = 4, cex = 0.65)
  mtext("Línea vertical: 2020, cambio de recolección durante la pandemia. Sin ajuste estacional.",
    side = 1, line = 5, cex = 0.65)
  dev.off()
}

# 9. GUARDAR UN INFORME DE RESULTADOS Y LIMITACIONES --------------------------
fmt <- function(x) formatC(x, digits = 2, format = "f", decimal.mark = ",")
informe <- c("# Indicadores laborales nacionales: Chile, AMJ 2010–2025", "",
  "## Método", "",
  "Se utiliza la base unificada existente. PET: personas de 15 años o más. activ = 1: ocupados; 2: desocupados; 3: fuera de la fuerza de trabajo. Se comprobó la consistencia con cae_especifico (1–7, 8–9 y 10–28, respectivamente).",
  "Se expanden personas con fact_cal, etiquetado en todos los años como factor trimestral con proyecciones Censo 2017. Las tasas se calculan como razones de totales ponderados: FT/PET, O/PET y D/FT, multiplicadas por 100.",
  "Los controles se guardan por año. Los menores de 15 no integran la PET. El script detiene el cálculo si detecta edades inválidas o problemas de actividad o pesos dentro de la PET; no elimina esos casos silenciosamente.",
  "La recalibración se aplicó retrospectivamente a la serie histórica; no se supone una ruptura automática en 2020 por el mero cambio de factor. Durante la pandemia sí cambiaron las condiciones de recolección y respuesta.", "",
  "## Comparaciones (puntos porcentuales)", "")
for (i in seq_len(nrow(comparaciones))) {
  z <- comparaciones[i, ]
  informe <- c(informe, sprintf("- %s, %d–%d: %s%% a %s%%; cambio de %s pp.",
    z$indicador, z$desde, z$hasta, fmt(z$tasa_inicial), fmt(z$tasa_final), fmt(z$cambio_pp)))
}
informe <- c(informe, "", "## Lectura conjunta", "")
for (v in tasas) {
  z <- indicadores[[v]]
  informe <- c(informe, sprintf("- %s: mínimo observado en AMJ %d (%s%%); máximo en AMJ %d (%s%%).",
    v, indicadores$anio[which.min(z)], fmt(min(z)), indicadores$anio[which.max(z)], fmt(max(z))))
}
caidas <- which(cambios$tasa_desocupacion_cambio_pp < 0)
for (i in caidas) informe <- c(informe, sprintf(
  "- En %d la desocupación bajó %s pp.; la ocupación cambió %s pp. y la participación %s pp. respecto de AMJ anterior.",
  cambios$anio[i], fmt(-cambios$tasa_desocupacion_cambio_pp[i]),
  fmt(cambios$tasa_ocupacion_cambio_pp[i]), fmt(cambios$tasa_participacion_cambio_pp[i])))
informe <- c(informe, "",
  "Una caída de la desocupación debe interpretarse junto con participación y ocupación: el desempleo también puede bajar cuando personas dejan la fuerza de trabajo. Los cambios observados son descriptivos; no identifican efectos causales de políticas.", "",
  "## Contraste y límites", "",
  sprintf("Se contrastaron seis tasas publicadas por el INE para AMJ 2020 y 2025: %d de 6 son compatibles con redondeo a un decimal.", sum(oficial$compatible_redondeo)),
  "El contraste es parcial: quedan pendientes las publicaciones de los otros años. Diferencias mayores al redondeo requieren revisar versiones de microdatos, factores, filtros y revisiones estadísticas; no se atribuyen automáticamente a una causa.",
  "Se compara exclusivamente AMJ de cada año; no son promedios anuales ni una serie mensual. La comparación del mismo trimestre no equivale a ajuste estacional. 2026 queda fuera. No se estiman intervalos ni significancia estadística porque no se implementó todavía la estimación de varianza con el diseño muestral complejo.",
  "Durante 2020 hubo cambios de recolección y pérdida de muestra asociados a la pandemia. La coincidencia con cifras publicadas no descarta sesgos de no respuesta ni garantiza comparabilidad perfecta.", "",
  "## Fuentes", "",
  "- [Metodología ENE, INE](https://www.ine.gob.cl/docs/default-source/ocupacion-y-desocupacion/metodologia/espanol/metodologia-ene-2020.pdf)",
  "- [Calibración histórica, INE](https://regiones.ine.cl/tarapaca/prensa/impacto-del-nuevo-m%C3%A9todo-de-calibraci%C3%B3n-de-los-factores-de-expansi%C3%B3n-en-la-ene.-tarapac%C3%A1)",
  paste0("- [Resultados AMJ 2020, INE](", url_2020, ")"),
  paste0("- [Resultados AMJ 2025, INE](", url_2025, ")"))
writeLines(enc2utf8(informe), file.path(carpeta_salida, "informe_nacional.md"), useBytes = TRUE)
capture.output(sessionInfo(), file = file.path(carpeta_salida, "sesion_R.txt"))

# 10. MOSTRAR RESULTADOS EN RSTUDIO ------------------------------------------
message("Terminado. Resultados: ", normalizePath(carpeta_salida, winslash = "/"))
# Descomente para abrir las tablas en RStudio:
# View(indicadores)
# View(comparaciones)
# View(controles)
# View(oficial)
