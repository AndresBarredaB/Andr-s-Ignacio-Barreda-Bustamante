# 1. OBJETIVO, PAQUETES Y RUTAS ----------------------------------------------
# Ejecutar con Source en RStudio. Todo el analisis se realiza en R.
# install.packages(c("survey", "openxlsx"))
# Etapa independiente: utiliza la union existente, no reemplaza 01-04.
for (p in c("survey", "openxlsx")) if (!requireNamespace(p, quietly=TRUE))
  stop('Falta ', p, '. Instale con install.packages(c("survey", "openxlsx"))')
carpeta_union_05 <- "C:/Users/andre/OneDrive/Documentos/resultados_union_ene/20261026_222723_68fc296a7de5"
carpeta_salida_05 <- file.path(getwd(), "resultados_05_sectores")

analizar_05 <- function(base=NULL, carpeta_union=carpeta_union_05,
                        carpeta_salida=carpeta_salida_05) {
  dir.create(carpeta_salida, recursive=TRUE, showWarnings=FALSE)
  salida <- tempfile(paste0(format(Sys.time(), "%Y%m%d_%H%M%S"), "_"), tmpdir=carpeta_salida)
  dir.create(salida); dir.create(file.path(salida,"graficos"))
  old <- options(survey.lonely.psu="certainty", survey.adjust.domain.lonely=FALSE)
  on.exit(options(old), add=TRUE)

  # 2. LEER LA UNION Y VALIDAR EL PERIODO Y LAS VARIABLES ---------------------
  if (is.null(base)) {
    message("Leyendo union existente; requiere varios GB de RAM...")
    base <- readRDS(file.path(carpeta_union,"ene_2010_2025_union_tecnica.rds"))
  }
  ramas <- c("b13_ciiu_rev3","b13_rev4cl_caenes","b14_rev4cl_caenes","r_p_rev4cl_caenes","b14_ciiu_rev3")
  cols <- c("edad","sexo","activ","cae_especifico","fact_cal","estrato","id_directorio",
            "conglomerado","ene_anio_origen","ene_archivo_origen","ene_fila_origen",
            "ano_trimestre","mes_central",ramas)
  if (!all(cols %in% names(base))) stop("Faltan columnas: ",paste(setdiff(cols,names(base)),collapse=", "))
  d <- as.data.frame(base[cols]); rm(base); invisible(gc())
  if (anyNA(d$ene_anio_origen)) stop("Hay filas sin anio de origen.")
  n2026 <- sum(d$ene_anio_origen==2026)
  d <- d[d$ene_anio_origen %in% 2010:2025, ]
  stopifnot(setequal(unique(d$ene_anio_origen),2010:2025),
            !anyNA(d$ano_trimestre), !anyNA(d$mes_central),
            all(d$ano_trimestre==d$ene_anio_origen),all(d$mes_central==5),
            !anyDuplicated(d[c("ene_archivo_origen","ene_fila_origen")]))
  atributos <- readRDS(file.path(carpeta_union,"atributos_originales_por_archivo.rds"))
  d$anio <- as.integer(d$ene_anio_origen)
  d$upm <- ifelse(d$anio<=2019,as.character(d$id_directorio),as.character(d$conglomerado))
  if (anyNA(d$edad) || any(!is.finite(d$edad) | d$edad<0 | d$edad!=floor(d$edad)) ||
      any(!is.finite(d$fact_cal) | d$fact_cal<=0) || anyNA(d$estrato) ||
      anyNA(d$upm) || any(d$upm=="")) stop("Revisar edad, ponderador o diseno: datos invalidos.")
  pet <- d$edad>=15
  if (any(!d$activ[pet] %in% 1:3) || any(!d$sexo[pet] %in% 1:2) ||
      any((d$activ[pet]==1)!=(d$cae_especifico[pet] %in% 1:7))) stop("Revisar activ, sexo y cae_especifico.")
  d$ocupado <- pet & d$activ %in% 1
  edades <- c("15-24","25-34","35-44","45-54","55-64","65+")
  d$grupo_edad <- as.character(cut(d$edad,c(15,25,35,45,55,65,Inf),right=FALSE,labels=edades))

  # 3. DOCUMENTAR LAS CLASIFICACIONES SIN EMPALMAR CONCEPTOS DISTINTOS --------
  # El alcance depende de ESTOS archivos: no se infiere de que una variable
  # exista en otras versiones de la ENE. No se mezcla donde trabaja con rama ajustada.
  cobertura <- data.frame(anio=2010:2025,
    bloque=c(rep("CIIU3_donde_trabaja_2010_2012",3),rep("CAENES_donde_trabaja_2013_2017",5),
             rep("CAENES_ajustada_2018_2025",8)),
    variable=c(rep(ramas[5],3),rep(ramas[3],5),rep(ramas[4],8)))
  disponibilidad <- list(); diccionario <- list(); etiquetas_ref <- list()
  for (y in 2010:2025) {
    archivos <- unique(d$ene_archivo_origen[d$anio==y])
    if (length(archivos)!=1) stop("Se esperaba un archivo por anio: ",y)
    k <- which(basename(names(atributos))==archivos)
    if (length(k)!=1) stop("No se identifican atributos: ",archivos)
    a <- atributos[[k]]
    if (!identical(as.numeric(a$activ$labels),c(1,2,3)) ||
        !identical(enc2utf8(names(a$activ$labels)),enc2utf8(c("Ocupados/as","Desocupados/as","Fuera de la fuerza de trabajo"))) ||
        !identical(as.numeric(a$sexo$labels),c(1,2)) ||
        !identical(enc2utf8(names(a$sexo$labels)),c("Hombre","Mujer")) ||
        !grepl("2017",a$fact_cal$label,fixed=TRUE)) stop("Cambio de codigos o factor: ",y)
    z <- d[d$anio==y & d$ocupado, ]
    for (v in ramas) disponibilidad[[length(disponibilidad)+1L]] <- data.frame(
      anio=y,variable=v,presente_original=v %in% names(a),n_ocupados=nrow(z),
      n_con_dato=sum(!is.na(z[[v]])),etiqueta=if(v %in% names(a)) a[[v]]$label else "No existe en original")
    v <- cobertura$variable[cobertura$anio==y]; b <- cobertura$bloque[cobertura$anio==y]
    if (!v %in% names(a)) stop("Variable seleccionada ausente en original: ",y," ",v)
    labs <- a[[v]]$labels
    validos <- if(y<=2012) 1:17 else 1:21
    if (!all(validos %in% as.numeric(labs))) stop("Etiquetas incompletas: ",y)
    nombres <- enc2utf8(names(labs)[match(validos,as.numeric(labs))])
    if (is.null(etiquetas_ref[[b]])) etiquetas_ref[[b]] <- nombres
    if (!identical(nombres,etiquetas_ref[[b]])) stop("Cambio de etiquetas dentro de bloque: ",y)
    diccionario[[length(diccionario)+1L]] <- data.frame(anio=y,bloque=b,variable=v,
       codigo=c(validos,999,998),sector=c(nombres,"Sin clasificacion (999)","Sin dato (NA)"))
    if (any(!is.na(z[[v]]) & !z[[v]] %in% c(validos,999)))
      stop("Codigos de rama desconocidos en ocupados: ",y)
  }
  disponibilidad <- do.call(rbind,disponibilidad); diccionario <- do.call(rbind,diccionario)

  # 4. DEFINIR INDICADORES, DOMINIOS Y PRECISION MUESTRAL ---------------------
  # Participacion = ocupados del sector / TODOS los ocupados del grupo.
  # Incluye sin clasificacion y sin dato en el denominador; no es tasa de empleo.
  # n son personas encuestadas; ocupados_exp son personas expandidas con fact_cal.
  dominios <- data.frame(tipo=c("Nacional",rep("Sexo",2),rep("Edad",6)),
    grupo=c("Total","Hombres","Mujeres",edades))
  calidad_p <- function(p,se,n,gl) {
    if (n<60 || gl<9 || !is.finite(se)) return("No fiable")
    if (p<=0 || p>=1) return("Limite 0/1: revisar")
    if (se<=min(p,1-p)^(2/3)/9) "Fiable" else "Poco fiable"
  }
  resultados <- list(); controles <- list(); contrastes <- list()
  for (y in 2010:2025) {
    message("Empleo sectorial y precision: AMJ ",y)
    z <- d[d$anio==y, ]; v <- cobertura$variable[cobertura$anio==y]
    b <- cobertura$bloque[cobertura$anio==y]
    cat <- diccionario[diccionario$anio==y, ]
    z$sector <- ifelse(is.na(z[[v]]),998,z[[v]])
    # Indicadores por sector, calculados simultaneamente para acelerar survey.
    variables <- paste0("s",cat$codigo)
    for (j in seq_along(variables)) z[[variables[j]]] <- as.numeric(z$ocupado & z$sector==cat$codigo[j])
    dis <- survey::svydesign(ids=~upm,strata=~estrato,weights=~fact_cal,data=z,nest=TRUE)
    form <- reformulate(variables)
    estructura <- unique(z[c("estrato","upm")])
    controles[[length(controles)+1L]] <- data.frame(anio=y,bloque=b,variable=v,
      n_total=nrow(z),n_ocupados=sum(z$ocupado),ocupados_exp=sum(z$fact_cal[z$ocupado]),
      n_sin_dato=sum(z$ocupado & z$sector==998),n_sin_clasificacion=sum(z$ocupado & z$sector==999),
      estratos_una_upm=sum(table(estructura$estrato)==1))
    # Cuantificar diferencias observables; no utilizarlas como conversion automatica.
    for (par in list(c(ramas[2],ramas[3]),c(ramas[2],ramas[4]))) {
      ok <- z$ocupado & !is.na(z[[par[1]]]) & !is.na(z[[par[2]]])
      w <- sum(z$fact_cal[ok]); dist <- ok & !is.na(z[[par[1]]]) & !is.na(z[[par[2]]]) &
        z[[par[1]]]!=z[[par[2]]]
      contrastes[[length(contrastes)+1L]] <- data.frame(anio=y,variable_a=par[1],variable_b=par[2],
        n_pares=sum(ok),diferentes=sum(dist,na.rm=TRUE),
        pct_diferentes=if(w>0)100*sum(z$fact_cal[which(dist)])/w else NA_real_)
    }
    for (i in seq_len(nrow(dominios))) {
      tipo <- dominios$tipo[i]; grupo <- dominios$grupo[i]
      sel <- z$ocupado
      if(tipo=="Sexo") sel <- sel & z$sexo==if(grupo=="Hombres")1 else 2
      if(tipo=="Edad") sel <- sel & !is.na(z$grupo_edad) & z$grupo_edad==grupo
      dom <- dis[sel, ]; zz <- z[sel, ]; gl <- survey::degf(dom)
      tot <- survey::svytotal(form,dom); pro <- survey::svymean(form,dom)
      t <- as.numeric(coef(tot)); et <- as.numeric(survey::SE(tot))
      p <- as.numeric(coef(pro)); ep <- as.numeric(survey::SE(pro))
      # gl del sector para evaluar su total; gl del denominador para proporciones.
      n <- vapply(cat$codigo,function(k) sum(zz$sector==k),integer(1))
      gls <- vapply(cat$codigo,function(k) {
        u <- unique(zz[zz$sector==k,c("estrato","upm")]); nrow(u)-length(unique(u$estrato))
      },integer(1))
      cv <- ifelse(t>0,100*et/t,NA_real_)
      qt_total <- qt(.975,pmax(gls,1))
      lo <- ifelse(t>0 & gls>0,t*exp(-qt_total*et/t),NA_real_)
      hi <- ifelse(t>0 & gls>0,t*exp(qt_total*et/t),NA_real_)
      # IC logit-t: limites respetan 0-100; extremos sin IC, no precision ficticia.
      lp <- hp <- rep(NA_real_,length(p)); ok <- p>0 & p<1 & gl>0
      lp[ok] <- 100*plogis(qlogis(p[ok])-qt(.975,max(gl,1))*ep[ok]/(p[ok]*(1-p[ok])))
      hp[ok] <- 100*plogis(qlogis(p[ok])+qt(.975,max(gl,1))*ep[ok]/(p[ok]*(1-p[ok])))
      ct <- ifelse(n==0,"Sin casos: no interpretar cero",ifelse(n<60 | gls<9 | !is.finite(cv),
           "No fiable",ifelse(cv<=15,"Fiable",ifelse(cv<=30,"Poco fiable","No fiable"))))
      cp <- vapply(seq_along(p),function(j)calidad_p(p[j],ep[j],nrow(zz),gl),character(1))
      resultados[[length(resultados)+1L]] <- data.frame(anio=y,bloque=b,variable=v,tipo=tipo,grupo=grupo,
        codigo=cat$codigo,sector=cat$sector,n_sector=n,n_grupo=nrow(zz),gl_sector=gls,gl_grupo=gl,
        ocupados_exp=t,ee_personas=et,cv_pct=cv,ic95_inf_personas=lo,ic95_sup_personas=hi,
        calidad_total=ct,participacion_pct=100*p,ee_pp=100*ep,ic95_inf_pct=lp,ic95_sup_pct=hp,
        calidad_participacion=cp)
    }
    rm(z,dis,dom); invisible(gc())
  }
  resultados <- do.call(rbind,resultados); controles <- do.call(rbind,controles)
  contrastes <- do.call(rbind,contrastes)

  # 5. RECONCILIAR SECTORES, SEXOS Y EDADES CON EL TOTAL -----------------------
  nacional <- resultados[resultados$tipo=="Nacional", ]
  reconciliacion <- do.call(rbind,lapply(2010:2025,function(y) {
    r <- resultados[resultados$anio==y, ]; c <- controles[controles$anio==y, ]
    nn <- r[r$tipo=="Nacional", ]
    data.frame(anio=y,diferencia_total=sum(nn$ocupados_exp)-c$ocupados_exp,
      diferencia_sexo=sum(r$ocupados_exp[r$tipo=="Sexo"])-c$ocupados_exp,
      diferencia_edad=sum(r$ocupados_exp[r$tipo=="Edad"])-c$ocupados_exp,
      diferencia_100=sum(nn$participacion_pct)-100,
      max_error_sector_sexo=max(abs(tapply(r$ocupados_exp[r$tipo=="Sexo"],r$codigo[r$tipo=="Sexo"],sum)-
        setNames(nn$ocupados_exp,nn$codigo)[names(tapply(r$ocupados_exp[r$tipo=="Sexo"],r$codigo[r$tipo=="Sexo"],sum))])))
  }))
  stopifnot(max(abs(as.matrix(reconciliacion[-1])))<1e-5)
  checks_grupos <- aggregate(participacion_pct~anio+tipo+grupo,resultados,sum)
  stopifnot(max(abs(checks_grupos$participacion_pct-100))<1e-7)

  # 6. MEDIR CAMBIOS SOLO DENTRO DE LA RAMA AJUSTADA --------------------------
  comparaciones <- list(c(2018,2025),c(2019,2020),c(2020,2025),c(2019,2025))
  cambios <- do.call(rbind,lapply(comparaciones,function(ys) {
    a <- nacional[nacional$anio==ys[1], ]; b <- nacional[nacional$anio==ys[2], ]
    b <- b[match(a$codigo,b$codigo), ]; stopifnot(all(a$bloque==b$bloque))
    data.frame(desde=ys[1],hasta=ys[2],codigo=a$codigo,sector=a$sector,
      ocupados_inicial=a$ocupados_exp,ocupados_final=b$ocupados_exp,
      cambio_personas=b$ocupados_exp-a$ocupados_exp,
      variacion_pct=ifelse(a$ocupados_exp>0,100*(b$ocupados_exp/a$ocupados_exp-1),NA_real_),
      cambio_pp=b$participacion_pct-a$participacion_pct,
      calidad_inicial=a$calidad_total,calidad_final=b$calidad_total,
      inferencia="Cambio descriptivo; sin prueba de significancia")
  }))

  # 7. CREAR GRAFICOS LEGIBLES EN PNG ----------------------------------------
  nombres_cortos <- c("Agro, silvicultura y pesca","Mineria","Manufactura","Electricidad y gas",
    "Agua y residuos","Construccion","Comercio","Transporte","Alojamiento y comidas",
    "Informacion y comunicaciones","Finanzas y seguros","Inmobiliarias","Profesionales y tecnicas",
    "Servicios administrativos","Administracion publica","Ensenanza","Salud y asistencia social",
    "Arte y recreacion","Otros servicios","Hogares empleadores","Extraterritoriales")
  nombres <- function(codigo) ifelse(codigo<=21,nombres_cortos[pmin(codigo,21)],"Sin clasificar/dato")
  abrir <- function(nombre) {
    png(file.path(salida,"graficos",nombre),width=1800,height=1150,res=160)
    par(mar=c(5,13,5,2),bg="white",col.axis="#334155",col.lab="#334155",las=1)
  }
  pie <- function(texto="Elaboracion propia. ENE, INE. AMJ; no promedios anuales.")
    mtext(texto,side=1,line=3.7,cex=.65,adj=0)
  ult <- nacional[nacional$anio==2025 & nacional$codigo<=21 & nacional$calidad_total=="Fiable", ]
  ult <- ult[order(ult$ocupados_exp), ]; top <- tail(ult,10)
  abrir("01_empleo_sectores_2025.png")
  yy <- barplot(top$ocupados_exp/1000,horiz=TRUE,names.arg=nombres(top$codigo),col="#147D92",border=NA,
    xlim=c(0,max(top$ic95_sup_personas)/1000*1.12),xlab="Miles de personas ocupadas",
    main="Los 10 sectores con mas empleo | AMJ 2025",cex.names=.8)
  segments(top$ic95_inf_personas/1000,yy,top$ic95_sup_personas/1000,yy,col="#172B4D",lwd=2)
  pie("Elaboracion propia. ENE, INE. Rama ajustada. Segmentos: IC 95% del nivel."); dev.off()
  codigos <- tail(ult$codigo,6)
  abrir("02_evolucion_sectores_2018_2025.png"); par(mar=c(5,5,5,2))
  colores <- c("#007F86","#C45136","#6155A6","#C48A16","#2476AB","#7B8543")
  maximo <- max(nacional$ocupados_exp[nacional$anio>=2018 & nacional$codigo %in% codigos])/1000
  plot(NA,xlim=c(2018,2025),ylim=c(0,maximo*1.3),xlab="Anio (trimestre abril-junio)",ylab="Miles de ocupados",
       main="Evolucion de los seis mayores sectores de 2025")
  abline(v=2020,col="#D1D5DB",lty=3)
  for(j in seq_along(codigos)) {
    rr <- nacional[nacional$anio>=2018 & nacional$codigo==codigos[j], ]
    lines(rr$anio,ifelse(rr$calidad_total=="Fiable",rr$ocupados_exp/1000,NA),col=colores[j],lwd=2,type="o",pch=16)
  }
  legend("topleft",legend=nombres(codigos),col=colores,lty=1,pch=16,ncol=2,bty="n",cex=.72)
  pie("Elaboracion propia. ENE, INE. Rama ajustada; solo niveles con calidad total fiable.");dev.off()
  for(pair in list(c(2019,2020),c(2019,2025))) {
    cc <- cambios[cambios$desde==pair[1] & cambios$hasta==pair[2] & cambios$codigo<=21 &
       cambios$calidad_inicial=="Fiable" & cambios$calidad_final=="Fiable", ]
    cc <- cc[order(cc$cambio_personas), ]
    abrir(paste0("03_cambio_",pair[1],"_",pair[2],".png"))
    barplot(cc$cambio_personas/1000,horiz=TRUE,names.arg=nombres(cc$codigo),cex.names=.65,
      col=ifelse(cc$cambio_personas<0,"#C45136","#147D92"),border=NA,
      xlab="Diferencia de miles de personas ocupadas",
      main=paste0("Cambio sectorial AMJ ",pair[1]," a ",pair[2]));abline(v=0,col="#334155")
    pie("Elaboracion propia. ENE, INE. Cambio descriptivo; no indica significancia estadistica.");dev.off()
  }
  for(tipo in c("Sexo","Edad")) {
    rr <- resultados[resultados$anio==2025 & resultados$tipo==tipo & resultados$codigo %in% tail(ult$codigo,10), ]
    grupos <- dominios$grupo[dominios$tipo==tipo]; cod <- tail(ult$codigo,10)
    # Construccion explicita por claves; no depender del orden de las filas.
    mat <- sapply(grupos,function(g) {r <- rr[rr$grupo==g, ]; r$participacion_pct[match(cod,r$codigo)]})
    calidad <- sapply(grupos,function(g) {r <- rr[rr$grupo==g, ]; r$calidad_participacion[match(cod,r$codigo)]})
    abrir(paste0("04_estructura_",tolower(tipo),"_2025.png"));par(mar=c(5,13,5,4))
    image(seq_along(grupos),seq_along(cod),t(mat),axes=FALSE,xlab="",ylab="",
      col=colorRampPalette(c("#F1F5F9","#147D92"))(40),main=paste0("Estructura sectorial por ",tolower(tipo)," | AMJ 2025"))
    axis(1,at=seq_along(grupos),labels=grupos);axis(2,at=seq_along(cod),labels=nombres(cod),las=1,cex.axis=.75)
    for(i in seq_along(cod)) for(j in seq_along(grupos)) text(j,i,
      paste0(formatC(mat[i,j],digits=1,format="f"),"%",if(calidad[i,j]!="Fiable")"*" else ""),
      col=if(mat[i,j]>max(mat)*.55)"white" else "#172B4D",cex=.8)
    pie("% del empleo de cada grupo. Solo 10 sectores. * Precision limitada. Fuente: ENE, INE.");dev.off()
  }

  # 8. REDACTAR EL INFORME Y LA METODOLOGIA ----------------------------------
  fuentes <- c(
    "https://stat.ine.cl/OECDStat_Metadata/ShowMetadata.ashx?DataSet=ENE_OCU_RAMA",
    "https://www.ine.gob.cl/docs/default-source/ocupacion-y-desocupacion/bbdd/libro-de-codigos/codigos-ene-2020.pdf",
    "https://www.ine.gob.cl/docs/default-source/buenas-practicas/estandares/estandar/documento/estandar-evaluacion-de-calidad-de-estimaciones.pdf")
  metodo <- c(
    "Chile, ENE. Cortes abril-junio (AMJ), 2010-2025; no son promedios anuales. 2026 excluido.",
    "2010-2012: b14_ciiu_rev3; 2013-2017: b14_rev4cl_caenes (donde trabaja); 2018-2025: r_p_rev4cl_caenes (ajustada). Sin empalme entre bloques.",
    "b13 (quien paga) solo esta informado para parte de los ocupados: no se usa como rama nacional. b14 (donde trabaja) se mantiene como antecedente separado de la rama ajustada.",
    "Poblacion: personas ocupadas de 15+ (activ=1). Peso: fact_cal, Censo 2017 segun atributos originales.",
    "Ocupados_exp: suma de factores. Participacion_pct: porcentaje del empleo de cada grupo localizado en el sector; no tasa de ocupacion o desempleo.",
    "Sexo y edad son desgloses separados, no cruce simultaneo sexo por edad. Grupos: 15-24,25-34,35-44,45-54,55-64,65+.",
    "999 y NA se conservan separados en el denominador y tablas. Otros codigos detienen el analisis. No se imputan ramas.",
    "Diseno por anio antes de seleccionar dominios: estrato; id_directorio 2010-2019 y conglomerado 2020-2025; nest=TRUE.",
    "EE por linealizacion Taylor, pesos tratados como fijos, sin correccion de poblacion finita. No reproduce toda la incertidumbre de calibracion.",
    "survey.lonely.psu=certainty: estratos con una UPM aportan cero a la varianza. Es una convencion, no prueba seleccion con certeza; ver Controles.",
    "IC95 totales: aproximacion log-t, gl del dominio sector-grupo. IC95 participaciones: logit-t, gl del grupo ocupado. Extremos sin IC se dejan vacios.",
    "Referencia academica de calidad INE 2020: totales n>=60,gl>=9,CV<=15% fiable; 15-30% poco fiable; resto no fiable.",
    "Participaciones: n denominador>=60,gl>=9,EE<=min(p,1-p)^(2/3)/9 fiable; EE mayor poco fiable. Extremos 0/1 requieren revision.",
    "Aplicacion orientativa a estas estimaciones; no certificacion INE. Revisar calidad_total y calidad_participacion por separado.",
    "Sin casos muestrales: total estimado cero no demuestra ausencia poblacional. No interpretar como un cero preciso.",
    "Cambios: diferencias descriptivas, no efectos causales, creacion neta de puestos individuales ni pruebas de significancia; no se estima covarianza entre anios.",
    "Los ocupados pueden cambiar de sector entre cortes; no se sigue a las mismas personas. No se calculan tasas de desempleo por sector.",
    "Excel contiene resultados calculados en R; modificar celdas no recalcula survey. Para actualizar, vuelva a ejecutar el script.",
    "Excel verificado mediante relectura en R; no equivale a comprobar su apertura en la aplicacion Excel.")
  principal <- nacional[nacional$anio==2025, ]; principal <- principal[order(-principal$ocupados_exp), ]
  fmt <- function(x,dig=0) formatC(x,format="f",digits=dig,big.mark=".",decimal.mark=",")
  ranking <- head(principal[principal$codigo<=21 & principal$calidad_total=="Fiable", ],5)
  hallazgos_cambio <- unlist(lapply(c(2020,2025),function(y) {
    cc <- cambios[cambios$desde==2019 & cambios$hasta==y & cambios$codigo<=21 &
       cambios$calidad_inicial=="Fiable" & cambios$calidad_final=="Fiable", ]
    cc <- cc[order(cc$cambio_personas), ]; ii <- unique(c(seq_len(3),tail(seq_len(nrow(cc)),3)))
    c(paste0("### AMJ 2019 a ",y),paste0("- ",cc$sector[ii],": cambio de ",fmt(cc$cambio_personas[ii]),
       " personas (",fmt(cc$variacion_pct[ii],1),"%)."))
  }))
  hallazgos_grupo <- unlist(lapply(c("Hombres","Mujeres","15-24","65+"),function(g) {
    rr <- resultados[resultados$anio==2025 & resultados$grupo==g & resultados$codigo<=21 &
      resultados$calidad_participacion=="Fiable", ]; rr <- head(rr[order(-rr$participacion_pct), ],3)
    paste0("- ",g,": ",paste(paste0(rr$sector," (",fmt(rr$participacion_pct,1),"%)"),collapse="; "),".")
  }))
  informe <- c("# 05. Empleo por sectores productivos en Chile", "",
    "## 1. Que se hizo", "Se analizaron los cortes AMJ con la union ya existente, sin modificar las bases originales.","",
    "## 2. Limite de comparabilidad", metodo[1:3],
    "La serie principal ajustada disponible es 2018-2025. Los bloques anteriores son antecedentes separados. No se ha construido una serie sectorial homogenea 2010-2025.","",
    "## 3. Principales sectores en AMJ 2025",
    paste0("- ",ranking$sector,": ",fmt(ranking$ocupados_exp)," ocupados; ",fmt(ranking$participacion_pct,1),"% del empleo nacional."),"",
    "## 4. Pandemia y recuperacion", "Las tablas Cambios comparan 2019-2020, 2020-2025, 2019-2025 y 2018-2025 dentro de la rama ajustada.",
    "Los aumentos o caidas describen diferencias entre estimaciones. No demuestran efectos de una politica ni significancia estadistica.","",
    hallazgos_cambio,"",
    "## 5. Sexo y edad", "Sexo y Edad muestran donde se distribuye el empleo de cada grupo. Un 20% significa que 20 de cada 100 ocupados de ese grupo estan en ese sector. No significa que ese grupo represente el 20% de quienes trabajan en el sector.","",
    hallazgos_grupo,"",
    "## 6. Controles y precision",paste0("Maxima diferencia de reconciliacion: ",format(max(abs(as.matrix(reconciliacion[-1]))))," personas o puntos porcentuales, segun columna."),
    paste0("Filas excluidas de 2026: ",n2026,". Celdas de totales con calidad distinta de Fiable: ",sum(resultados$calidad_total!="Fiable")," de ",nrow(resultados),"."),
    "Los graficos de cambios incluyen sectores con ambos niveles fiables; esto no evalua la precision de la diferencia.","",
    "## 7. Metodologia",paste0("- ",metodo[4:length(metodo)]),"",
    "## 8. Fuentes",paste0("- ",fuentes),"",
    "## 9. Proximo paso para Politica Economica", "Relacionar esta evolucion descriptiva con PIB real, inversion e inflacion oficiales, respetando frecuencias y coberturas. Luego construir una cronologia documentada de politicas de empleo. No atribuir causalidad con coincidencias temporales.")
  writeLines(enc2utf8(informe),file.path(salida,"informe_05_sectores.md"),useBytes=TRUE)

  # 9. EXPORTAR UN EXCEL REAL Y TABLAS REUTILIZABLES EN R ---------------------
  hojas <- list(Resumen_2025=principal,Cambios=cambios,
    Rama_ajustada=nacional[nacional$anio>=2018, ],
    Historico_CIIU3=nacional[nacional$anio<=2012, ],
    Historico_CAENES=nacional[nacional$anio %in% 2013:2017, ],
    Sexo=resultados[resultados$tipo=="Sexo", ],Edad=resultados[resultados$tipo=="Edad", ],
    Cobertura=cobertura,Disponibilidad=disponibilidad,Diccionario=diccionario,
    Contraste_variables=contrastes,Controles=controles,Reconciliacion=reconciliacion,
    Metodologia=data.frame(nota=c(metodo,fuentes)))
  wb <- openxlsx::createWorkbook(creator="Analisis ENE en R")
  encabezado <- openxlsx::createStyle(fgFill="#17365D",fontColour="white",textDecoration="bold",wrapText=TRUE,valign="center")
  decimal <- openxlsx::createStyle(numFmt="#,##0.00")
  for(nm in names(hojas)) {
    x <- hojas[[nm]]; openxlsx::addWorksheet(wb,nm,gridLines=FALSE)
    openxlsx::writeData(wb,nm,x,withFilter=nrow(x)>1,headerStyle=encabezado,keepNA=FALSE)
    openxlsx::freezePane(wb,nm,firstRow=TRUE,firstCol=TRUE)
    openxlsx::setRowHeights(wb,nm,1,45)
    for(j in seq_along(x)) {
      w <- if(names(x)[j] %in% c("nota","sector","etiqueta","inferencia")) 62 else
        if(is.character(x[[j]])) 29 else max(14,min(23,nchar(names(x)[j])+2))
      openxlsx::setColWidths(wb,nm,j,w)
      if(is.numeric(x[[j]]) && !names(x)[j] %in% c("anio","codigo","desde","hasta") && !grepl("^(n_|gl_)",names(x)[j]))
        openxlsx::addStyle(wb,nm,decimal,rows=2:(nrow(x)+1),cols=j,gridExpand=TRUE)
      if(is.character(x[[j]])) openxlsx::addStyle(wb,nm,openxlsx::createStyle(wrapText=TRUE,valign="top"),
         rows=2:(nrow(x)+1),cols=j,gridExpand=TRUE,stack=TRUE)
    }
    openxlsx::setRowHeights(wb,nm,2:(nrow(x)+1),if(nm=="Metodologia")70 else 42)
    qc <- grep("^calidad",names(x))
    for(j in qc) {
      malas <- which(x[[j]]!="Fiable")+1L
      if(length(malas)) openxlsx::addStyle(wb,nm,openxlsx::createStyle(fgFill="#FFF0CF",fontColour="#7C4200",wrapText=TRUE),
        rows=malas,cols=j,gridExpand=TRUE,stack=TRUE)
    }
  }
  archivo <- file.path(salida,"05_resultados_sectores.xlsx")
  openxlsx::saveWorkbook(wb,archivo,overwrite=FALSE)
  saveRDS(hojas,file.path(salida,"tablas_05.rds"))

  # 10. REABRIR EL EXCEL Y VERIFICAR QUE CONSERVA LOS RESULTADOS ---------------
  verificacion <- lapply(names(hojas),function(nm) {
    x <- openxlsx::read.xlsx(archivo,sheet=nm,check.names=FALSE)
    ref <- hojas[[nm]]
    stopifnot(identical(dim(x),dim(ref)),identical(names(x),names(ref)))
    for(j in which(vapply(ref,is.numeric,logical(1))))
      stopifnot(isTRUE(all.equal(as.numeric(x[[j]]),as.numeric(ref[[j]]),tolerance=1e-10)))
    data.frame(hoja=nm,filas=nrow(x),columnas=ncol(x),lectura="Correcta",numeros="Coinciden con R")
  })
  write.csv(do.call(rbind,verificacion),file.path(salida,"verificacion_excel.csv"),row.names=FALSE)
  capture.output(sessionInfo(),file=file.path(salida,"sesion_R_05.txt"))
  message("Etapa 05 terminada: ",normalizePath(salida,winslash="/"))
  print(ranking[c("sector","ocupados_exp","participacion_pct")],row.names=FALSE)
  invisible(list(carpeta=normalizePath(salida,winslash="/"),tablas=hojas))
}

# 11. EJECUTAR Y CONSULTAR LOS RESULTADOS EN RSTUDIO --------------------------
resultados_05 <- analizar_05(if(exists("ene",inherits=FALSE)) ene else NULL)
# View(resultados_05$tablas$Resumen_2025)
# View(resultados_05$tablas$Cambios)
# View(resultados_05$tablas$Sexo)
# View(resultados_05$tablas$Edad)
# resultados_05$carpeta
