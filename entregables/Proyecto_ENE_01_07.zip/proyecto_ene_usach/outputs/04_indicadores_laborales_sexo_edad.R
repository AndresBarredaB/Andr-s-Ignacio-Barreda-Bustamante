# 1. OBJETIVO, PAQUETES Y RUTAS ----------------------------------------------
# Politica Economica: Chile, abril-junio (AMJ), 2010-2025.
# Este script desarrolla la etapa 04; usa la union existente, sin repetirla.
# Abrir en RStudio y pulsar Source. Instalar una sola vez si hace falta:
# install.packages(c("survey", "openxlsx"))
for (paquete in c("survey", "openxlsx")) {
  if (!requireNamespace(paquete, quietly = TRUE))
    stop('Falta ', paquete, '. Ejecute install.packages(c("survey", "openxlsx"))')
}
carpeta_union_04 <- "C:/Users/andre/OneDrive/Documentos/resultados_union_ene/20261026_222723_68fc296a7de5"
carpeta_salida_04 <- file.path(getwd(), "resultados_04_sexo_edad")

analizar_04 <- function(base = NULL, carpeta_union = carpeta_union_04,
                        carpeta_salida = carpeta_salida_04) {
  dir.create(carpeta_salida, recursive = TRUE, showWarnings = FALSE)
  salida <- tempfile(paste0(format(Sys.time(), "%Y%m%d_%H%M%S"), "_"), tmpdir = carpeta_salida)
  dir.create(salida)
  dir.create(file.path(salida, "graficos"))
  guardar <- function(x, nombre) write.csv(x, file.path(salida, nombre), row.names = FALSE,
                                          fileEncoding = "UTF-8", na = "")
  opciones_previas <- options(survey.lonely.psu = "certainty", survey.adjust.domain.lonely = FALSE)
  on.exit(options(opciones_previas), add = TRUE)
  # "certainty": un estrato con una sola UPM aporta cero a la varianza.
  # Convencion del codigo de uso ENE del INE; su frecuencia queda registrada.

  # 2. CARGAR LA UNION Y CONSERVAR SOLO LAS COLUMNAS NECESARIAS ----------------
  if (is.null(base)) {
    message("Cargando la base unificada (requiere varios GB de RAM)...")
    base <- readRDS(file.path(carpeta_union, "ene_2010_2025_union_tecnica.rds"))
  }
  necesarias <- c("edad", "sexo", "activ", "cae_especifico", "fact_cal", "estrato",
    "id_directorio", "conglomerado", "ene_anio_origen", "ene_trimestre_origen",
    "ene_archivo_origen", "ene_fila_origen", "ano_trimestre", "mes_central")
  if (!all(necesarias %in% names(base)))
    stop("Faltan variables: ", paste(setdiff(necesarias, names(base)), collapse = ", "))
  d <- as.data.frame(base[necesarias])
  rm(base); invisible(gc())
  if (anyNA(d$ene_anio_origen)) stop("Hay filas sin anio de origen.")
  d <- d[d$ene_anio_origen %in% 2010:2025, ]
  if (!setequal(unique(d$ene_anio_origen), 2010:2025)) stop("Faltan anios principales.")
  if (anyNA(d$ene_trimestre_origen) || any(tolower(d$ene_trimestre_origen) != "amj"))
    stop("Se esperaba AMJ exclusivamente.")
  if (anyNA(d$ano_trimestre) || anyNA(d$mes_central) ||
      any(d$ano_trimestre != d$ene_anio_origen) || any(d$mes_central != 5))
    stop("El anio o mes central interno no coincide con AMJ del anio de origen.")
  if (anyDuplicated(d[c("ene_archivo_origen", "ene_fila_origen")])) stop("Filas de origen duplicadas.")

  # 3. VERIFICAR ETIQUETAS ORIGINALES DE SEXO Y ACTIVIDAD -----------------------
  atributos <- readRDS(file.path(carpeta_union, "atributos_originales_por_archivo.rds"))
  for (f in unique(d$ene_archivo_origen)) {
    k <- which(basename(names(atributos)) == f)
    if (length(k) != 1L) stop("Atributos no identificados para ", f)
    a <- atributos[[k]]
    if (!identical(as.numeric(a$sexo$labels), c(1, 2)) ||
        !identical(enc2utf8(names(a$sexo$labels)), c("Hombre", "Mujer")))
      stop("Codigos de sexo diferentes en ", f)
    if (!identical(as.numeric(a$activ$labels), c(1, 2, 3)) ||
        !identical(enc2utf8(names(a$activ$labels)),
                   enc2utf8(c("Ocupados/as", "Desocupados/as", "Fuera de la fuerza de trabajo"))))
      stop("Revisar codigos de activ en ", f)
    if (!grepl("2017", a$fact_cal$label, fixed = TRUE)) stop("Revisar version de fact_cal en ", f)
  }

  # 4. REVISAR FALTANTES Y CREAR GRUPOS DE EDAD SIN CAMBIAR ORIGINALES ----------
  d$anio <- as.integer(d$ene_anio_origen)
  d$edad_valida <- is.finite(d$edad) & d$edad >= 0 & d$edad == floor(d$edad)
  d$pet <- d$edad_valida & d$edad >= 15
  d$sexo_valido <- d$sexo %in% 1:2
  d$peso_valido <- is.finite(d$fact_cal) & d$fact_cal > 0
  d$activ_valida <- d$activ %in% 1:3
  d$activ_cae <- ifelse(d$cae_especifico %in% 1:7, 1L,
    ifelse(d$cae_especifico %in% 8:9, 2L, ifelse(d$cae_especifico %in% 10:28, 3L, NA_integer_)))
  d$upm <- ifelse(d$anio <= 2019, as.character(d$id_directorio), as.character(d$conglomerado))
  edades <- c("15-24", "25-34", "35-44", "45-54", "55-64", "65+")
  d$grupo_edad <- as.character(cut(d$edad, breaks = c(15,25,35,45,55,65,Inf),
                                   right = FALSE, labels = edades))
  d$sexo_nombre <- ifelse(d$sexo == 1, "Hombres", ifelse(d$sexo == 2, "Mujeres", NA))
  controles <- do.call(rbind, lapply(2010:2025, function(y) {
    z <- d[d$anio == y, ]
    data.frame(anio = y, n_total = nrow(z), n_pet = sum(z$pet),
      edad_faltante = sum(is.na(z$edad)), edad_invalida = sum(!z$edad_valida & !is.na(z$edad)),
      sexo_faltante_pet = sum(z$pet & is.na(z$sexo)),
      sexo_invalido_pet = sum(z$pet & !is.na(z$sexo) & !z$sexo_valido),
      activ_faltante_pet = sum(z$pet & is.na(z$activ)),
      activ_invalida_pet = sum(z$pet & !is.na(z$activ) & !z$activ_valida),
      peso_faltante = sum(is.na(z$fact_cal)),
      peso_invalido = sum(!is.na(z$fact_cal) & !z$peso_valido),
      diseno_faltante = sum(is.na(z$estrato) | is.na(z$upm) | z$upm == ""),
      pet_sin_grupo_edad = sum(z$pet & is.na(z$grupo_edad)),
      discrepancia_cae_pet = sum(z$pet & (is.na(z$activ_cae) | !z$activ_valida |
        (!is.na(z$activ_cae) & z$activ_valida & z$activ_cae != z$activ)), na.rm = TRUE))
  }))
  guardar(controles, "controles_datos.csv")
  if (any(as.matrix(controles[setdiff(names(controles), c("anio","n_total","n_pet"))]) > 0))
    stop("Revisar controles_datos.csv. El calculo se detiene sin excluir casos silenciosamente.")
  d$ocupado <- as.numeric(d$pet & d$activ %in% 1)
  d$desocupado <- as.numeric(d$pet & d$activ %in% 2)
  d$en_ft <- as.numeric(d$pet & d$activ %in% 1:2)
  d$fuera_ft <- as.numeric(d$pet & d$activ %in% 3)
  # El diseno se crea antes de seleccionar dominios. No se declara cada grupo
  # como si fuese una muestra independiente.

  # 5. DEFINIR DOMINIOS Y CRITERIOS DE PRECISION -------------------------------
  dominios <- rbind(
    data.frame(nivel="Nacional_control", sexo="Total", edad="Total"),
    data.frame(nivel="Sexo", sexo=c("Hombres","Mujeres"), edad="Total"),
    data.frame(nivel="Edad", sexo="Total", edad=edades),
    data.frame(nivel="Sexo_edad", expand.grid(sexo=c("Hombres","Mujeres"), edad=edades,
                                               stringsAsFactors=FALSE)),
    data.frame(nivel="Jovenes_adultos", sexo="Total", edad=c("15-24","25+")))
  tasa_nombres <- c("Participación", "Ocupación", "Desocupación")
  # Estandar INE 2020: n del denominador >= 60; gl del dominio >= 9;
  # EE <= min(p, 1-p)^(2/3)/9. Aplicacion academica a cortes transversales.
  # No se usa el CV de 15% como regla para estas tasas (son proporciones).
  calidad_tasa <- function(p, ee, n, gl) {
    if (!is.finite(p)) return("No estimable")
    if (!is.finite(ee) || gl <= 0) return("Precision no evaluable")
    if (n < 60 || gl < 9) return("No fiable")
    if (p <= 0 || p >= 1) return("Limite 0/1: revisar")
    if (ee <= min(p, 1-p)^(2/3)/9) "Fiable" else "Poco fiable"
  }
  poblaciones_lista <- list(); tasas_lista <- list(); diseno_lista <- list()
  for (y in 2010:2025) {
    message("Calculando tasas y precision: AMJ ", y)
    z <- d[d$anio == y, ]
    diseno <- survey::svydesign(ids=~upm, strata=~estrato, weights=~fact_cal, nest=TRUE, data=z)
    estructura <- unique(z[c("estrato", "upm")])
    nh <- table(estructura$estrato)
    diseno_lista[[length(diseno_lista)+1L]] <- data.frame(anio=y,
      variable_upm=ifelse(y<=2019,"id_directorio","conglomerado"),
      estratos=length(nh), upm=nrow(estructura), estratos_una_upm=sum(nh==1),
      gl_nacional=survey::degf(diseno), tratamiento_upm_solitaria="certainty")
    for (i in seq_len(nrow(dominios))) {
      g <- dominios[i, ]
      mascara <- z$pet
      if (g$sexo != "Total") mascara <- mascara & z$sexo_nombre == g$sexo
      if (g$edad == "25+") mascara <- mascara & z$edad >= 25
      else if (g$edad != "Total") mascara <- mascara & z$grupo_edad == g$edad
      mascara[is.na(mascara)] <- FALSE
      a <- z[mascara, ]
      poblaciones_lista[[length(poblaciones_lista)+1L]] <- data.frame(anio=y, g,
        n_pet=nrow(a), n_ocupados=sum(a$ocupado), n_desocupados=sum(a$desocupado),
        n_fuera_ft=sum(a$fuera_ft), n_ft=sum(a$en_ft),
        PET=sum(a$fact_cal), ocupados=sum(a$fact_cal*a$ocupado),
        desocupados=sum(a$fact_cal*a$desocupado), fuera_ft=sum(a$fact_cal*a$fuera_ft),
        fuerza_trabajo=sum(a$fact_cal*a$en_ft), row.names=NULL)
      for (j in 1:3) {
        incluir <- mascara & if (j==3) z$en_ft==1 else TRUE
        n <- sum(incluir)
        sub <- diseno[incluir, ]
        gl <- if (n) survey::degf(sub) else 0
        p <- ee <- inferior <- superior <- NA_real_
        variable <- c("en_ft","ocupado","desocupado")[j]
        if (n && sum(z$fact_cal[incluir])>0) {
          estimacion <- survey::svymean(stats::reformulate(variable), sub)
          p <- as.numeric(coef(estimacion)); ee <- as.numeric(survey::SE(estimacion))
          # IC95 logit con EE por Taylor y t con gl del dominio.
          if (gl>0 && is.finite(ee) && p>0 && p<1) {
            margen <- qt(0.975, df=gl)*ee/(p*(1-p))
            inferior <- plogis(qlogis(p)-margen)
            superior <- plogis(qlogis(p)+margen)
          }
          # Control independiente de estimacion puntual: razon de sumas.
          razon <- sum(z$fact_cal[incluir]*z[[variable]][incluir])/sum(z$fact_cal[incluir])
          stopifnot(abs(p-razon)<1e-10)
        }
        tasas_lista[[length(tasas_lista)+1L]] <- data.frame(anio=y, g,
          indicador=tasa_nombres[j], tasa_pct=100*p, ee_pp=100*ee,
          ic95_inferior_pct=100*inferior, ic95_superior_pct=100*superior,
          n_denominador=n, gl=gl, calidad=calidad_tasa(p,ee,n,gl), row.names=NULL)
      }
    }
    rm(diseno, z, sub); invisible(gc())
  }
  poblaciones <- do.call(rbind, poblaciones_lista)
  tasas <- do.call(rbind, tasas_lista)
  disenos <- do.call(rbind, diseno_lista)
  stopifnot(all(tasas$tasa_pct>=0 & tasas$tasa_pct<=100, na.rm=TRUE))

  # 6. RECONCILIAR SEXO, EDAD Y SEXO-EDAD CON EL TOTAL NACIONAL ----------------
  variables_total <- c("n_pet","n_ocupados","n_desocupados","n_fuera_ft","n_ft",
                       "PET","ocupados","desocupados","fuera_ft","fuerza_trabajo")
  reconciliacion <- do.call(rbind, lapply(2010:2025, function(y) {
    nacional <- poblaciones[poblaciones$anio==y & poblaciones$nivel=="Nacional_control", ]
    do.call(rbind, lapply(c("Sexo","Edad","Sexo_edad","Jovenes_adultos"), function(nivel) {
      a <- poblaciones[poblaciones$anio==y & poblaciones$nivel==nivel, ]
      diferencias <- colSums(a[variables_total])-as.numeric(nacional[1,variables_total])
      data.frame(anio=y, nivel=nivel, variable=variables_total, diferencia=diferencias,
        coincide=abs(diferencias)<0.01)
    }))
  }))
  guardar(reconciliacion, "reconciliacion.csv")
  stopifnot(all(reconciliacion$coincide))
  stopifnot(all(abs(with(poblaciones,PET-ocupados-desocupados-fuera_ft))<0.01))

  # 7. CALCULAR BRECHAS MUJERES MENOS HOMBRES Y JOVENES MENOS ADULTOS ----------
  hacer_brecha <- function(a,b,claves) {
    a <- a[c(claves,"tasa_pct","calidad")]; b <- b[c(claves,"tasa_pct","calidad")]
    x <- merge(a,b,by=claves,suffixes=c("_a","_b"),all=TRUE)
    x$brecha_pp <- x$tasa_pct_a-x$tasa_pct_b
    x$lectura <- "Diferencia descriptiva; sin prueba de significancia"
    x
  }
  brechas <- hacer_brecha(tasas[tasas$nivel %in% c("Sexo","Sexo_edad") & tasas$sexo=="Mujeres", ],
    tasas[tasas$nivel %in% c("Sexo","Sexo_edad") & tasas$sexo=="Hombres", ],
    c("anio","nivel","edad","indicador"))
  names(brechas)[names(brechas)=="tasa_pct_a"] <- "mujeres_pct"
  names(brechas)[names(brechas)=="tasa_pct_b"] <- "hombres_pct"
  jovenes <- hacer_brecha(tasas[tasas$nivel=="Jovenes_adultos" & tasas$edad=="15-24", ],
    tasas[tasas$nivel=="Jovenes_adultos" & tasas$edad=="25+", ],c("anio","indicador"))
  names(jovenes)[names(jovenes)=="tasa_pct_a"] <- "jovenes_15_24_pct"
  names(jovenes)[names(jovenes)=="tasa_pct_b"] <- "adultos_25_mas_pct"

  # 8. COMPARAR PERIODOS Y REVISAR RECUPERACION RESPECTO DE 2019 ---------------
  pares <- data.frame(desde=c(2010,2019,2019,2019),hasta=c(2025,2020,2021,2025))
  comparaciones <- do.call(rbind,lapply(seq_len(nrow(pares)),function(i) {
    a <- tasas[tasas$anio==pares$desde[i], ]; b <- tasas[tasas$anio==pares$hasta[i], ]
    x <- merge(a,b,by=c("nivel","sexo","edad","indicador"),suffixes=c("_inicial","_final"))
    x$cambio_pp <- x$tasa_pct_final-x$tasa_pct_inicial
    x[c("nivel","sexo","edad","indicador","anio_inicial","anio_final", "tasa_pct_inicial",
        "tasa_pct_final","cambio_pp","calidad_inicial","calidad_final")]
  }))
  recuperacion <- comparaciones[comparaciones$anio_inicial==2019 & comparaciones$anio_final==2025, ]
  recuperacion$posicion_2025 <- ifelse(recuperacion$cambio_pp>=0,"Igual o por encima de 2019","Por debajo de 2019")
  # Esta etiqueta describe el nivel; estar por encima en desocupacion NO es mejora.
  tabulados <- aggregate(tasas$calidad=="Fiable", tasas[c("anio","nivel","indicador")], mean)
  names(tabulados)[4] <- "fraccion_celdas_fiables"
  tabulados$mayoria_fiable <- tabulados$fraccion_celdas_fiables>0.5

  # 9. GENERAR GRAFICOS EN PNG -----------------------------------------------
  col_sexo <- c(Hombres="#215B86", Mujeres="#A14470")
  iniciar_png <- function(nombre, paneles=c(1,1)) {
    png(file.path(salida,"graficos",nombre),width=2000,height=if(prod(paneles)>1)1500 else 1100,res=180)
    par(mfrow=paneles,mar=c(3.8,4.5,2.7,1),oma=c(3,0,2,0),las=1)
  }
  pie <- function() mtext("Fuente: ENE, INE; fact_cal. AMJ de cada año. IC95 en tablas; comparaciones descriptivas.",
                         outer=TRUE,side=1,line=1,cex=0.8)
  ejes <- function(titulo,limites,brecha=FALSE) {
    plot(2010:2025,rep(NA_real_,16),type="n",xaxt="n",xlab="Año (AMJ)",
         ylab=if(brecha) "Puntos porcentuales" else "Porcentaje (%)",ylim=limites, main=titulo)
    axis(1,at=seq(2010,2025,3)); grid(nx=NA,ny=NULL,col="#E3E6EA")
    abline(v=2020,lty=3,col="#AAAAAA")
    if(brecha) abline(h=0,col="#444444")
  }
  for (j in 1:3) {
    indicador <- tasa_nombres[j]; slug <- c("participacion","ocupacion","desocupacion")[j]
    a <- tasas[tasas$nivel=="Sexo" & tasas$indicador==indicador, ]
    iniciar_png(paste0("01_",slug,"_sexo.png"))
    ejes(paste(indicador,"por sexo"),c(0,if(j==3)25 else 100))
    for(s in names(col_sexo)) {
      z <- a[a$sexo==s, ]; lines(z$anio,z$tasa_pct,type="o",pch=16,col=col_sexo[s],lwd=2)
    }
    legend("topright",names(col_sexo),col=col_sexo,lty=1,pch=16,bty="n"); pie(); dev.off()
    iniciar_png(paste0("03_",slug,"_edad.png"),c(2,3))
    limite <- if(j==3)max(35,ceiling(max(tasas$tasa_pct[tasas$nivel=="Edad" & tasas$indicador==indicador],na.rm=TRUE)/5)*5) else 100
    for(e in edades) {
      z <- tasas[tasas$nivel=="Edad" & tasas$edad==e & tasas$indicador==indicador, ]
      ejes(paste(e,"años"),c(0,limite)); lines(z$anio,z$tasa_pct,type="o",pch=16,col="#215B86",lwd=2)
    }
    mtext(paste(indicador,"por edad | AMJ 2010-2025"),outer=TRUE,side=3,font=2); pie(); dev.off()
    iniciar_png(paste0("04_",slug,"_sexo_edad_comparacion.png"),c(1,2))
    for(s in names(col_sexo)) {
      z <- tasas[tasas$nivel=="Sexo_edad" & tasas$sexo==s & tasas$indicador==indicador & tasas$anio %in% c(2019,2020,2025), ]
      # Construccion explicita evita depender del orden de filas.
      mat <- sapply(c(2019,2020,2025),function(y) vapply(edades,function(e)
        z$tasa_pct[z$anio==y & z$edad==e],numeric(1)))
      matplot(seq_along(edades),mat,type="o",pch=c(16,17,15),lty=1,col=c("#4C6380","#BD6725","#317C68"),
        xaxt="n",xlab="Grupo de edad",ylab="Porcentaje (%)",ylim=c(0,if(j==3)40 else 100),main=s)
      axis(1,at=seq_along(edades),labels=edades); legend("topright",c("2019","2020","2025"),
        col=c("#4C6380","#BD6725","#317C68"),lty=1,pch=c(16,17,15),bty="n")
    }
    mtext(paste(indicador,"por sexo y edad"),outer=TRUE,side=3,font=2); pie(); dev.off()
  }
  iniciar_png("02_brechas_sexo.png",c(1,3))
  for(indicador in tasa_nombres) {
    z <- brechas[brechas$nivel=="Sexo" & brechas$indicador==indicador, ]
    ejes(indicador,range(c(0,z$brecha_pp))*1.15,TRUE)
    lines(z$anio,z$brecha_pp,type="o",pch=16,col="#6C518A",lwd=2)
  }
  mtext("Brechas: mujeres menos hombres",outer=TRUE,side=3,font=2); pie(); dev.off()

  # 10. PREPARAR INFORME Y FUENTES PARA EL REPASO FINAL ------------------------
  formato <- function(x) formatC(x,digits=2,format="f",decimal.mark=",")
  fuente_metodo <- "https://www.ine.gob.cl/docs/default-source/ocupacion-y-desocupacion/metodologia/espanol/metodologia-ene-2020.pdf"
  fuente_calidad <- "https://www.ine.gob.cl/docs/default-source/buenas-practicas/estandares/estandar/documento/estandar-evaluacion-de-calidad-de-estimaciones.pdf"
  fuente_diseno <- "https://www.ine.gob.cl/docs/default-source/ocupacion-y-desocupacion/publicaciones-y-anuarios/separatas/tematicas/estimacion-anual-2022.pdf"
  fuente_tutorial <- "https://www.ine.gob.cl/calidad-estadistica/directrices-metodologicas/tutorial-paquete-calidad"
  lectura <- c("# Etapa 04: empleo y desempleo por sexo y edad", "",
    "## Método y alcance", "",
    "Se reutilizó la base unificada de AMJ 2010-2025. Se verificaron sexo (1 hombre, 2 mujer), activ (1 ocupado, 2 desocupado, 3 fuera de la fuerza de trabajo), edad y fact_cal con los atributos originales. Se mantuvieron los originales. 2026 no se incluyó.",
    "La PET comprende personas de 15 años o más. Los grupos son 15-24, 25-34, 35-44, 45-54, 55-64 y 65+. El agregado 25+ se calculó desde sus personas y ponderadores, no promediando tasas. Las tasas usan el denominador de cada grupo.",
    "Se construyó un diseño survey separado por año: estrato; id_directorio hasta 2019 y conglomerado desde 2020; peso fact_cal y nest=TRUE. Las subpoblaciones se seleccionaron después de declarar el diseño. Los errores estándar usan linealización de Taylor, sin corrección de población finita, con pesos calibrados tratados como fijos. Los IC95 usan transformación logit y t con grados de libertad del dominio.",
    sprintf("Siguiendo el ejemplo del INE, los estratos con una sola UPM contribuyen cero a la varianza (certainty); se registraron %d casos estrato-año. Esta convención puede limitar la estimación de incertidumbre y no prueba selección con certeza.",sum(disenos$estratos_una_upm)),
    "Se aplicaron como referencia académica los criterios transversales INE 2020: tamaño del denominador >=60, grados de libertad >=9 y máximo error estándar tolerable según la proporción. No es una certificación del INE ni una reevaluación oficial de sus publicaciones históricas. Los criterios no califican la significancia de brechas o cambios entre años.", "",
    "## Brechas entre mujeres y hombres", "")
  for(ind in tasa_nombres) {
    z <- brechas[brechas$nivel=="Sexo" & brechas$indicador==ind & brechas$anio %in% c(2010,2019,2020,2025), ]
    lectura <- c(lectura,paste0("- ",ind,": ",paste(paste0(z$anio,": ",formato(z$brecha_pp)," pp"),collapse="; "),". Brecha = mujeres menos hombres."))
  }
  lectura <- c(lectura,"","## Jóvenes y personas de 25 años o más","")
  for(y in c(2010,2019,2020,2021,2025)) {
    z <- jovenes[jovenes$anio==y & jovenes$indicador=="Desocupación", ]
    lectura <- c(lectura,sprintf("- AMJ %d: desocupación de 15-24 años %s%%; de 25+ %s%%; diferencia %s pp.",
      y,formato(z$jovenes_15_24_pct),formato(z$adultos_25_mas_pct),formato(z$brecha_pp)))
  }
  for(y0 in c(2019,2020)) {
    z0 <- tasas[tasas$nivel=="Jovenes_adultos" & tasas$edad=="15-24" & tasas$anio==y0, ]
    z1 <- tasas[tasas$nivel=="Jovenes_adultos" & tasas$edad=="15-24" & tasas$anio==2025, ]
    cambio <- z1$tasa_pct[match(tasa_nombres,z1$indicador)]-z0$tasa_pct[match(tasa_nombres,z0$indicador)]
    lectura <- c(lectura,paste0("- Jóvenes, ",y0,"-2025: ",paste(paste0(tasa_nombres," ",formato(cambio)," pp"),collapse="; "),"."))
  }
  lectura <- c(lectura,"","## Recuperación y grupos con mayores dificultades","")
  for(nivel in c("Sexo","Edad","Sexo_edad")) {
    actual <- tasas[tasas$nivel==nivel & tasas$anio==2025, ]
    for(ind in c("Desocupación","Ocupación")) {
      z <- actual[actual$indicador==ind, ]
      k <- if(ind=="Desocupación") which.max(z$tasa_pct) else which.min(z$tasa_pct)
      lectura <- c(lectura,sprintf("- %s, AMJ 2025: %s %s, %s %s%% (%s).",
        nivel,z$sexo[k],z$edad[k],if(ind=="Desocupación")"mayor desocupación" else "menor ocupación",
        formato(z$tasa_pct[k]),z$calidad[k]))
    }
    shock <- comparaciones[comparaciones$nivel==nivel & comparaciones$anio_inicial==2019 &
      comparaciones$anio_final==2020 & comparaciones$indicador=="Ocupación", ]
    k <- which.min(shock$cambio_pp)
    lectura <- c(lectura,sprintf("- Mayor caída de ocupación 2019-2020 (%s): %s %s, %s pp.",
      nivel,shock$sexo[k],shock$edad[k],formato(shock$cambio_pp[k])))
  }
  for(s in c("Hombres","Mujeres")) {
    z <- recuperacion[recuperacion$nivel=="Sexo" & recuperacion$sexo==s, ]
    lectura <- c(lectura,paste0("- ",s,", cambios 2019-2025: ",paste(paste0(z$indicador," ",formato(z$cambio_pp)," pp"),collapse="; "),"."))
  }
  for(ind in c("Participación","Ocupación")) {
    z <- recuperacion[recuperacion$nivel=="Sexo_edad" & recuperacion$indicador==ind, ]
    arriba <- paste(paste(z$sexo[z$cambio_pp>=0],z$edad[z$cambio_pp>=0]),collapse=", ")
    abajo <- paste(paste(z$sexo[z$cambio_pp<0],z$edad[z$cambio_pp<0]),collapse=", ")
    lectura <- c(lectura,paste0("- ",ind,": en 2025 alcanzan o superan su tasa de 2019: ",if(nchar(arriba))arriba else "ninguno","."),
      paste0("  Permanecen por debajo: ",if(nchar(abajo))abajo else "ninguno",". Comparación de estimaciones puntuales."))
  }
  lectura <- c(lectura,"","## Interpretación y límites", "",
    "El desempleo debe leerse junto con ocupación y participación: su disminución no implica por sí sola creación de empleo. Las tablas permiten contrastar simultáneamente los tres cambios. En jóvenes, estudiar puede influir en la participación; en 65+ influye el retiro. Estos mecanismos no se identificaron causalmente aquí.",
    "Las diferencias por sexo no identifican por sí mismas discriminación; pueden reflejar múltiples factores. Los cambios entre años no siguen necesariamente a las mismas personas. Los grupos no están ajustados por composición educativa, edad interna u otras características.",
    "Los IC95 corresponden a cada tasa por separado. No se calcularon intervalos ni pruebas para diferencias: no se asume independencia entre grupos o cortes, y no se concluye significancia a partir de superposición de intervalos.",
    "Se compara AMJ, no promedios anuales. Las condiciones de recolección y respuesta cambiaron durante la pandemia. No se desarrollaron sectores, macroeconomía ni evaluación causal de políticas.",
    sprintf("Calidad de las %d tasas: %s.",nrow(tasas),paste(paste(names(table(tasas$calidad)),as.integer(table(tasas$calidad)),sep=": "),collapse="; ")),"",
    "## Estimaciones que requieren cautela", "")
  advertidas <- tasas[tasas$calidad!="Fiable", ]
  if(nrow(advertidas)) for(i in seq_len(nrow(advertidas))) {
    z <- advertidas[i, ]
    lectura <- c(lectura,sprintf("- %d, %s %s, %s: %s%%; IC95 [%s%%, %s%%]; %s. No fundamentar una conclusión fuerte en esta celda.",
      z$anio,z$sexo,z$edad,z$indicador,formato(z$tasa_pct),formato(z$ic95_inferior_pct),formato(z$ic95_superior_pct),z$calidad))
  }
  lectura <- c(lectura,"", "## Fuentes", "",paste0("- [Metodología ENE](",fuente_metodo,")"),
    paste0("- [Diseño tradicional y conglomerados](",fuente_diseno,")"),
    paste0("- [Tutorial INE de diseño y calidad](",fuente_tutorial,")"),
    paste0("- [Estándar de calidad INE 2020](",fuente_calidad,")"))
  writeLines(enc2utf8(lectura),file.path(salida,"informe_04_sexo_edad.md"),useBytes=TRUE)

  # 11. EXPORTAR UN EXCEL REAL CON HOJAS LEGIBLES ------------------------------
  # Resultados numericos calculados en R; el Excel es una salida, no un modelo editable.
  hacer_tabla <- function(nivel) {
    p <- poblaciones[poblaciones$nivel==nivel, ]; t <- tasas[tasas$nivel==nivel, ]
    for(j in 1:3) {
      z <- t[t$indicador==tasa_nombres[j], ]; clave <- paste(p$anio,p$sexo,p$edad)
      p[[paste0(c("participacion","ocupacion","desocupacion")[j],"_pct")]] <-
        z$tasa_pct[match(clave,paste(z$anio,z$sexo,z$edad))]
      p[[paste0(c("participacion","ocupacion","desocupacion")[j],"_calidad")]] <-
        z$calidad[match(clave,paste(z$anio,z$sexo,z$edad))]
    }
    p[c("anio","sexo","edad","participacion_pct","ocupacion_pct","desocupacion_pct",
        "participacion_calidad","ocupacion_calidad","desocupacion_calidad",
        "PET","ocupados","desocupados","fuera_ft","fuerza_trabajo",
        "n_pet","n_ocupados","n_desocupados","n_fuera_ft","n_ft")]
  }
  resumen <- tasas[tasas$nivel=="Sexo" & tasas$anio %in% c(2010,2019,2020,2025),
                   c("anio","sexo","indicador","tasa_pct","ic95_inferior_pct","ic95_superior_pct","calidad")]
  notas <- data.frame(tema=c("Alcance","Universo","Ponderador","Tasas","Brechas","Jóvenes","IC95",
    "UPM solitarias","Calidad","Cambios","Faltantes","Unidades","Fuente microdatos","Metodología","Diseño","Calidad INE","Ejecución"),
    detalle=c("Chile, AMJ 2010-2025. No promedios anuales. 2026 excluido.",
      "Personas de 15 años o más. Sexo según códigos y etiquetas originales.",
      "fact_cal: factor trimestral calibrado con proyecciones Censo 2017.",
      "Participación=100*FT/PET; ocupación=100*O/PET; desocupación=100*D/FT, dentro de cada grupo.",
      "Mujeres menos hombres, en puntos porcentuales; no pruebas de significancia.",
      "15-24 frente a 25+; tasas de 25+ calculadas desde totales ponderados.",
      "Taylor con survey; intervalo logit-t95 por tasa y dominio. Pesos fijos; sin corrección finita.",
      "certainty: aporte cero de estratos con una UPM, siguiendo ejemplo INE. Ver Diseño.",
      "Referencia INE 2020: n>=60, gl>=9 y EE tolerable. Aplicación académica, no certificación INE.",
      "Comparaciones descriptivas. No se supone independencia entre años ni se estiman IC de cambios.",
      "No se excluyeron casos silenciosamente: el programa se detiene si detecta problemas en controles.",
      "Tasas en 0-100; cambios en pp; poblaciones expandidas en personas; n_ indica muestra.",
      file.path(carpeta_union,"ene_2010_2025_union_tecnica.rds"),fuente_metodo,fuente_diseno,fuente_calidad,
      "Abrir 04 en RStudio; instalar survey y openxlsx; Source. El Excel se regenera desde R."))
  hojas <- list(Resumen=resumen, Sexo=hacer_tabla("Sexo"), Edad=hacer_tabla("Edad"),
    Sexo_edad=hacer_tabla("Sexo_edad"), Brechas_sexo=brechas, Jovenes_adultos=jovenes,
    Comparaciones=comparaciones, Recuperacion=recuperacion, Precision=tasas,
    Calidad_tabulados=tabulados, Controles=controles, Reconciliacion=reconciliacion,
    Diseno=disenos, Notas=notas)
  wb <- openxlsx::createWorkbook(creator="Proyecto Política Económica")
  titulo <- openxlsx::createStyle(fontName="Arial",fontSize=14,textDecoration="bold",fontColour="#203B52")
  encabezado <- openxlsx::createStyle(fontName="Arial",fontSize=10,textDecoration="bold",
    fgFill="#203B52",fontColour="#FFFFFF",halign="center",valign="center",wrapText=TRUE)
  cuerpo <- openxlsx::createStyle(fontName="Arial",fontSize=10,valign="center")
  decimal <- openxlsx::createStyle(numFmt="0.00")
  entero <- openxlsx::createStyle(numFmt="#,##0")
  alerta <- openxlsx::createStyle(fontColour="#9C0006",bgFill="#FCE4D6")
  for(nm in names(hojas)) {
    x <- hojas[[nm]]
    openxlsx::addWorksheet(wb,nm,gridLines=FALSE)
    openxlsx::writeData(wb,nm,paste("ENE AMJ 2010-2025 —",gsub("_"," ",nm)),startRow=2,colNames=FALSE)
    openxlsx::addStyle(wb,nm,titulo,rows=2,cols=1)
    openxlsx::writeData(wb,nm,x,startRow=4,headerStyle=encabezado,withFilter=TRUE,keepNA=FALSE)
    openxlsx::addStyle(wb,nm,cuerpo,rows=5:(nrow(x)+4),cols=seq_len(ncol(x)),gridExpand=TRUE,stack=TRUE)
    openxlsx::setRowHeights(wb,nm,rows=4,heights=42)
    openxlsx::setRowHeights(wb,nm,rows=5:(nrow(x)+4),heights=18)
    openxlsx::setColWidths(wb,nm,cols=seq_len(ncol(x)),widths=20)
    for(j in seq_len(ncol(x))) {
      col <- names(x)[j]
      if(is.numeric(x[[j]])) {
        est <- if(grepl("pct|pp|tasa|diferencia|fraccion",col))decimal else entero
        openxlsx::addStyle(wb,nm,est,rows=5:(nrow(x)+4),cols=j,gridExpand=TRUE,stack=TRUE)
        if(grepl("^anio|^desde|^hasta",col))
          openxlsx::addStyle(wb,nm,openxlsx::createStyle(numFmt="0"),rows=5:(nrow(x)+4),cols=j,stack=TRUE)
      }
      if(col %in% c("sexo","edad")) openxlsx::setColWidths(wb,nm,cols=j,widths=13)
      if(grepl("calidad|nivel|indicador|lectura|posicion",col)) openxlsx::setColWidths(wb,nm,cols=j,widths=28)
      if(col=="lectura") openxlsx::setColWidths(wb,nm,cols=j,widths=61)
      if(grepl("calidad",col)) openxlsx::conditionalFormatting(wb,nm,cols=j,rows=5:(nrow(x)+4),
        type="expression",rule=paste0('AND(',openxlsx::int2col(j),'5<>"Fiable",',
          openxlsx::int2col(j),'5<>"")'),style=alerta)
    }
    openxlsx::freezePane(wb,nm,firstActiveRow=5,firstActiveCol=4)
    if(nm=="Notas") {
      openxlsx::setColWidths(wb,nm,cols=1:2,widths=c(22,105))
      openxlsx::addStyle(wb,nm,openxlsx::createStyle(wrapText=TRUE,valign="top"),
        rows=5:(nrow(x)+4),cols=2,gridExpand=TRUE,stack=TRUE)
      openxlsx::setRowHeights(wb,nm,rows=5:(nrow(x)+4),heights=42)
    }
  }
  archivo_excel <- file.path(salida,"04_resultados_sexo_edad.xlsx")
  openxlsx::saveWorkbook(wb,archivo_excel,overwrite=TRUE)
  # Releer el XLSX exportado y comprobar todas las hojas, filas y cifras numericas.
  for(nm in names(hojas)) {
    vuelta <- openxlsx::read.xlsx(archivo_excel,sheet=nm,startRow=4,check.names=FALSE)
    stopifnot(nrow(vuelta)==nrow(hojas[[nm]]),ncol(vuelta)==ncol(hojas[[nm]]))
    for(j in which(vapply(hojas[[nm]],is.numeric,logical(1))))
      stopifnot(isTRUE(all.equal(vuelta[[j]],hojas[[nm]][[j]],tolerance=1e-10,check.attributes=FALSE)))
  }
  saveRDS(hojas,file.path(salida,"tablas_04.rds"))
  capture.output(sessionInfo(),file=file.path(salida,"sesion_R_04.txt"))

  # 12. MOSTRAR DONDE QUEDARON LOS RESULTADOS ---------------------------------
  message("Etapa 04 terminada. Excel, informe y graficos: ",normalizePath(salida,winslash="/"))
  print(resumen[resumen$anio==2025, ],row.names=FALSE)
  invisible(list(carpeta=normalizePath(salida,winslash="/"),tablas=hojas))
}

# 13. EJECUTAR Y ABRIR TABLAS EN RSTUDIO --------------------------------------
resultados_04 <- analizar_04(if(exists("ene",inherits=FALSE)) ene else NULL)
# View(resultados_04$tablas$Sexo)
# View(resultados_04$tablas$Edad)
# View(resultados_04$tablas$Sexo_edad)
# View(resultados_04$tablas$Brechas_sexo)
# View(resultados_04$tablas$Precision)
